/* Haikei hero field: the design system's connected-dots background (§04).
 * One ripple on load and one on each click or tap; nearby dots brighten briefly.
 * Under prefers-reduced-motion it draws one still frame.
 *
 * Usage:
 *   import { mountHeroField } from '@haikeilabs/brand/hero-field.js';
 *   const stop = mountHeroField(document.querySelector('.hero'));
 *   // later, on route change: stop();
 *   // In Solid: onMount(() => { const stop = mountHeroField(ref); onCleanup(stop); });
 *
 * The host must be position: relative (and overflow: hidden); put its content above
 * the canvas (z-index: 1). The canvas is inserted as its first child, absolutely
 * positioned, aria-hidden, and ignores pointer events itself (clicks are read from
 * the host). Animation runs only while an effect is live and the host is visible.
 * Colours come from CSS custom properties on the host, with the dark-theme defaults:
 *   --hero-field-dot    (default rgba(255,255,255,.16))
 *   --hero-field-accent (default #6ee7b7, mint 300)
 *
 * Dependency-free. */

export interface HeroFieldOptions {
  /** Dot colour; overrides --hero-field-dot. */
  dot?: string
  /** Accent colour for lit dots, links and ripples; overrides --hero-field-accent. */
  accent?: string
  /** Load-ripple origin as a fraction of the host width (default 0.5). */
  originX?: number
  /** Load-ripple origin as a fraction of the host height (default 0.42). */
  originY?: number
}

type Cell = { x: number; y: number; lit: boolean }
type Ripple = { x: number; y: number; t: number }

/** Mounts the field into `host` and returns a function that stops it and removes the canvas. */
export function mountHeroField(host: HTMLElement, opts: HeroFieldOptions = {}): () => void {
  const cv = document.createElement('canvas')
  cv.setAttribute('aria-hidden', 'true')
  Object.assign(cv.style, { position: 'absolute', inset: '0', width: '100%', height: '100%', pointerEvents: 'none', zIndex: '0' })
  host.prepend(cv)
  const ctx = cv.getContext('2d') as CanvasRenderingContext2D
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches
  const css = getComputedStyle(host)
  const dot = opts.dot || css.getPropertyValue('--hero-field-dot').trim() || 'rgba(255,255,255,.16)'
  const acc = opts.accent || css.getPropertyValue('--hero-field-accent').trim() || '#6ee7b7'
  const RIPPLE_MS = 1800, SPEED = 0.42, BAND = 40

  let W = 0, H = 0, cell = 36, cells: Cell[] = [], links: [Cell, Cell][] = [], ripples: Ripple[] = [], raf = 0, visible = true
  let pointer: { x: number; y: number; t: number } | null = null
  let pending: { x: number; y: number } | null = null

  const seeded = (s: number) => () => (s = (s * 16807) % 2147483647) / 2147483647

  function layout() {
    const r = host.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1)
    W = r.width; H = r.height
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr)
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    cell = W < 600 ? 28 : 36
    const rnd = seeded(11)
    cells = []
    for (let y = cell / 2; y < H + cell; y += cell)
      for (let x = cell / 2; x < W + cell; x += cell) cells.push({ x, y, lit: rnd() < 0.05 })
    const pick = seeded(7), nodes = cells.filter(() => pick() < 0.06)
    links = []
    for (const n of nodes) {
      const near = nodes.filter(m => m !== n && Math.hypot(m.x - n.x, m.y - n.y) < cell * 3.2).slice(0, 2)
      for (const m of near) links.push([n, m])
    }
  }

  function boost(x: number, y: number, now: number) {
    let a = 0
    for (const r of ripples) {
      const age = now - r.t, band = Math.abs(Math.hypot(x - r.x, y - r.y) - age * SPEED)
      if (band < BAND) a += (1 - band / BAND) * (1 - age / RIPPLE_MS)
    }
    return a
  }

  function draw(now: number) {
    ripples = ripples.filter(r => now - r.t <= RIPPLE_MS)
    ctx.clearRect(0, 0, W, H)
    ctx.strokeStyle = acc; ctx.lineWidth = 1
    for (const [n, m] of links) {
      ctx.globalAlpha = 0.10 + 0.3 * boost((n.x + m.x) / 2, (n.y + m.y) / 2, now)
      ctx.beginPath(); ctx.moveTo(n.x, n.y); ctx.lineTo(m.x, m.y); ctx.stroke()
    }
    for (const c of cells) {
      const distance = pointer ? Math.hypot(c.x - pointer.x, c.y - pointer.y) : Infinity
      const b = boost(c.x, c.y, now) + (pointer ? Math.max(0, 1 - distance / 100) * Math.max(0, 1 - (now - pointer.t) / 500) * 0.55 : 0)
      if (c.lit) { ctx.globalAlpha = Math.min(0.55, 0.28 + b * 0.4); ctx.fillStyle = acc; ctx.beginPath(); ctx.arc(c.x, c.y, 2.2 + b * 1.6, 0, 7); ctx.fill() }
      else { ctx.globalAlpha = 0.55 + b * 0.45; ctx.fillStyle = b > 0.05 ? acc : dot; ctx.beginPath(); ctx.arc(c.x, c.y, 1.2 + b * 1.4, 0, 7); ctx.fill() }
    }
    ctx.globalAlpha = 1
  }

  const loop = (now: number) => {
    raf = 0
    if (!visible || document.hidden) return
    if (pending) {
      const r = host.getBoundingClientRect()
      pointer = { x: pending.x - r.left, y: pending.y - r.top, t: now }
      pending = null
    }
    if (pointer && now - pointer.t >= 500) pointer = null
    draw(now)
    if (ripples.length || pointer) raf = requestAnimationFrame(loop)
  }
  const kick = () => { if (!raf && !reduce && visible && !document.hidden) raf = requestAnimationFrame(loop) }
  const ripple = (x: number, y: number) => { if (reduce) return; ripples.push({ x, y, t: performance.now() }); kick() }

  const onDown = (e: PointerEvent) => { const r = host.getBoundingClientRect(); ripple(e.clientX - r.left, e.clientY - r.top) }
  const onMove = (e: PointerEvent) => { if (visible && !document.hidden) { pending = { x: e.clientX, y: e.clientY }; kick() } }
  const pause = () => { cancelAnimationFrame(raf); raf = 0; pointer = null; pending = null }
  const onVisibility = () => { if (document.hidden) pause(); else kick() }
  const ro = new ResizeObserver(() => { layout(); draw(performance.now()) })
  const io = new IntersectionObserver(([e]) => { visible = e.isIntersecting; if (visible) kick(); else pause() })

  layout(); draw(0)
  ro.observe(host); io.observe(host)
  host.addEventListener('pointerdown', onDown)
  if (!reduce) { host.addEventListener('pointermove', onMove); document.addEventListener('visibilitychange', onVisibility) }
  const first = reduce ? 0 : setTimeout(() => ripple(W * (opts.originX ?? 0.5), H * (opts.originY ?? 0.42)), 450)

  return function stop() {
    clearTimeout(first); pause()
    ro.disconnect(); io.disconnect()
    host.removeEventListener('pointerdown', onDown)
    host.removeEventListener('pointermove', onMove)
    if (!reduce) document.removeEventListener('visibilitychange', onVisibility)
    cv.remove()
  }
}
