/* KeiFlow: "Policy is central. Enforcement is local." as a scripted SVG (9 s loop).
 *
 * Usage:
 *   import '@haikeilabs/brand/kei-flow.css';
 *   import { KeiFlow } from '@haikeilabs/brand/kei-flow.js';
 *   const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
 *   const flow = KeiFlow(el, { title: false, static: reduce });
 *   // Drive it with requestAnimationFrame: flow.update(seconds).
 *
 * Give it a visible Pause control (§04). With `static: true` it renders the final
 * frame, which is what reduced motion shows — already paused. Colours come from the
 * CSS variables on `.kflow` in kei-flow.css.
 *
 * Ported unchanged in behaviour from the DX study prototype (where it was a classic
 * script assigning window.KeiFlow); dependency-free. */

export interface KeiFlowOptions {
  /** Draw the "HOW KEI WORKS" eyebrow and title inside the SVG. */
  title?: boolean
  /** Render the final frame instead of frame 0 (use under prefers-reduced-motion). */
  static?: boolean
}

export interface KeiFlowInstance {
  /** Render the frame at `t` seconds; wraps modulo `duration`. */
  update(t: number): void
  /** Loop length in seconds. */
  duration: number
  svg: SVGSVGElement
}

type Point = [number, number]

const DUR = 9
const NS = 'http://www.w3.org/2000/svg'
const el = (tag: string, attrs: Record<string, string | number>, parent?: Element): SVGElement => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, String(attrs[k])); if (parent) parent.appendChild(e); return e }
const txt = (parent: Element, x: number, y: number, s: string, cls: string, anchor?: string) => { const t = el('text', { x, y, class: cls, 'text-anchor': anchor || 'start' }, parent); t.textContent = s; return t }
const clamp = (v: number) => Math.max(0, Math.min(1, v))
const ease = (v: number) => v < .5 ? 2 * v * v : 1 - Math.pow(-2 * v + 2, 2) / 2
const prog = (t: number, a: number, b: number) => clamp((t - a) / (b - a))
function along(pts: Point[], f: number): Point {
  let L = 0; const seg: number[] = []
  for (let i = 1; i < pts.length; i++) { const d = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); seg.push(d); L += d }
  let r = f * L
  for (let i = 0; i < seg.length; i++) { if (r <= seg[i] || i === seg.length - 1) { const k = seg[i] ? r / seg[i] : 0; return [pts[i][0] + (pts[i + 1][0] - pts[i][0]) * k, pts[i][1] + (pts[i + 1][1] - pts[i][1]) * k] } r -= seg[i] }
  return pts[pts.length - 1]
}

/** Renders the How it works animation into `container` (replacing its contents). */
export function KeiFlow(container: Element, opts: KeiFlowOptions = {}): KeiFlowInstance {
  const top = opts.title ? 60 : -40
  const W = 1200, H = 660 + top
  container.innerHTML = ''
  const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, class: 'kflow', role: 'img', 'aria-label': 'Kei policy is written centrally and enforced locally on two paths: coding agents enforce it through their own permission settings, and agents built with Agentware are checked by the Kei runtime, which allows or denies each call. Every decision is recorded in the audit log.' }, container) as SVGSVGElement
  el('rect', { x: 0, y: 0, width: W, height: H, class: 'kf-bg' }, svg)
  const g = el('g', { transform: `translate(0 ${top})` }, svg)
  if (opts.title) {
    txt(svg, 60, 46, 'HOW KEI WORKS', 'kf-eyebrow')
    txt(svg, 60, 88, 'Policy is central. Enforcement is local.', 'kf-title')
  }
  const box = (x: number, y: number, w: number, h: number, title: string, sub: string | null) => {
    const r = el('rect', { x, y, width: w, height: h, rx: 12, class: 'kf-box' }, g)
    txt(g, x + 16, y + (sub ? 27 : h / 2 + 6), title, 'kf-h')
    if (sub) txt(g, x + 16, y + 48, sub, 'kf-s')
    return r
  }
  const line = (pts: Point[], cls: string) => el('polyline', { points: pts.map(p => p.join(',')).join(' '), class: cls }, g)
  const dot = (cls?: string) => el('circle', { r: 6, class: cls || 'kf-dot', opacity: 0 }, g)
  const pill = (x: number, y: number, label: string, cls: string) => { const p = el('g', { opacity: 0 }, g); el('rect', { x, y, width: label.length * 8.4 + 22, height: 24, rx: 12, class: cls + '-bg' }, p); txt(p, x + 11, y + 16.5, label, 'kf-pill ' + cls); return p }

  // Control plane
  txt(g, 40, 128, 'HAIKEI · OUTSIDE YOUR ENVIRONMENT', 'kf-cap')
  const cp = el('rect', { x: 40, y: 140, width: 240, height: 230, rx: 14, class: 'kf-box' }, g)
  txt(g, 60, 176, 'Kei control plane', 'kf-h')
  txt(g, 60, 198, 'Policy authority', 'kf-s')
  const bullets = ['Policies', 'Tool & connector catalog', 'Audit log'].map((b, i) => { el('rect', { x: 60, y: 226 + i * 30, width: 7, height: 7, rx: 2, class: 'kf-bul' }, g); return txt(g, 78, 234 + i * 30, b, 'kf-li') })

  // Environment
  el('rect', { x: 320, y: 110, width: 850, height: 460, rx: 18, class: 'kf-env' }, g)
  txt(g, 344, 138, 'YOUR ENVIRONMENT · YOUR CLOUD', 'kf-cap kf-mint')

  // Lane A
  txt(g, 350, 182, 'A · CLAUDE CODE · CODEX · OPENCODE', 'kf-cap')
  const kpA = box(350, 196, 200, 64, 'Kei runtime', 'renders native settings')
  const edA = box(610, 196, 220, 64, 'Editor permissions', 'allows, denies or asks')
  const reA = box(890, 196, 250, 64, 'Tool call proceeds', 'decided by the editor')
  // Lane B
  txt(g, 350, 352, 'B · AGENTWARE SDK · CONNECTORS', 'kf-cap')
  const awB = box(350, 366, 200, 64, 'Agentware', 'tool call + identity')
  const kpB = box(610, 366, 220, 64, 'Kei runtime', 'evaluates policy locally')
  const prB = box(890, 350, 250, 46, 'Provider call runs', null)
  const stB = box(890, 402, 250, 46, 'Stopped before the call', null)

  // Paths
  const P: Record<string, Point[]> = {
    syncA: [[280, 228], [350, 228]],
    syncB: [[280, 300], [300, 300], [300, 500], [680, 500], [680, 430]],
    a1: [[550, 228], [610, 228]], a2: [[830, 228], [890, 228]],
    b1: [[550, 398], [610, 398]],
    bAllow: [[830, 398], [860, 398], [860, 373], [890, 373]],
    bDeny: [[830, 398], [860, 398], [860, 425], [890, 425]],
    auditA: [[720, 196], [720, 160], [250, 160], [250, 140]],
    auditB: [[770, 430], [770, 540], [160, 540], [160, 370]],
  }
  line(P.syncA, 'kf-ln'); line(P.syncB, 'kf-ln')
  line(P.a1, 'kf-ln'); line(P.a2, 'kf-ln'); line(P.b1, 'kf-ln'); line(P.bAllow, 'kf-ln'); line(P.bDeny, 'kf-ln')
  line(P.auditA, 'kf-ln kf-dash'); line(P.auditB, 'kf-ln kf-dash')
  txt(g, 296, 220, 'sync', 'kf-tiny')
  txt(g, 420, 558, 'audit · every decision', 'kf-tiny')

  const pAllowA = pill(1040, 168, 'allow', 'kf-ok')
  const pAllow = pill(1068, 323, 'ALLOW', 'kf-ok')
  const pDeny = pill(1074, 455, 'DENY', 'kf-no')
  const pEval = pill(740, 338, 'checking', 'kf-ok')

  const dSyncA = dot(), dSyncB = dot(), dA = dot(), dB = dot(), dAud1 = dot('kf-dot kf-dot-dim'), dAud2 = dot('kf-dot kf-dot-dim')

  // Captions
  const capY = 612
  const cap = txt(svg, W / 2, top + capY, '', 'kf-capline', 'middle')
  const stepDots = [0, 1, 2, 3].map(i => el('circle', { cx: W / 2 - 27 + i * 18, cy: top + capY + 26, r: 4, class: 'kf-step' }, svg))
  const CAPS = ['1 · Policy is written once in Kei and synced to the runtime in your environment.',
    '2 · Coding agents: the editor enforces it with its own permission settings.',
    '3 · Your agents: the Kei runtime allows or denies each call before it runs.',
    '4 · Every decision is recorded, tied to who asked.']

  const place = (d: SVGElement, pts: Point[], f: number) => { if (f <= 0 || f >= 1) { d.setAttribute('opacity', '0'); return } const [x, y] = along(pts, ease(f)); d.setAttribute('cx', String(x)); d.setAttribute('cy', String(y)); d.setAttribute('opacity', '1') }
  const lit = (r: SVGElement, on: boolean, cls?: string) => r.setAttribute('class', 'kf-box' + (on ? ' ' + (cls || 'kf-on') : ''))
  const show = (p: SVGElement, on: boolean) => p.setAttribute('opacity', on ? '1' : '0')

  function update(t: number) {
    t = ((t % DUR) + DUR) % DUR
    const phase = t < 1.5 ? 0 : t < 3.5 ? 1 : t < 6.4 ? 2 : 3
    cap.textContent = CAPS[phase]
    stepDots.forEach((s, i) => s.setAttribute('class', 'kf-step' + (i === phase ? ' kf-step-on' : '')))
    lit(cp, t < 1.2 || (t > 6.6 && t < 8.4))
    bullets[0].setAttribute('class', 'kf-li' + (t < 1.2 ? ' kf-mint' : ''))
    bullets[2].setAttribute('class', 'kf-li' + (t > 6.6 && t < 8.4 ? ' kf-mint' : ''))
    place(dSyncA, P.syncA, prog(t, .2, 1.1)); place(dSyncB, P.syncB, prog(t, .2, 1.3))
    lit(kpA, (t > 1.1 && t < 2.2)); lit(kpB, (t > 1.3 && t < 1.8) || (t > 3.9 && t < 4.7) || (t > 5.3 && t < 5.9))
    // A
    place(dA, t < 2.3 ? P.a1 : P.a2, t < 2.3 ? prog(t, 1.6, 2.2) : prog(t, 2.6, 3.1))
    lit(edA, t > 2.2 && t < 3.0); lit(reA, t > 3.1 && t < 6.4); show(pAllowA, t > 3.1 && t < 6.4)
    // B allow then deny
    let bp: Point[] | null = null, bf = 0
    if (t >= 3.5 && t < 3.95) { bp = P.b1; bf = prog(t, 3.5, 3.95) }
    else if (t >= 4.6 && t < 5.0) { bp = P.bAllow; bf = prog(t, 4.6, 5.0) }
    else if (t >= 5.0 && t < 5.35) { bp = P.b1; bf = prog(t, 5.0, 5.35) }
    else if (t >= 5.85 && t < 6.25) { bp = P.bDeny; bf = prog(t, 5.85, 6.25) }
    if (bp) place(dB, bp, bf); else dB.setAttribute('opacity', '0')
    lit(awB, (t > 3.4 && t < 3.6) || (t > 4.95 && t < 5.15))
    show(pEval, (t > 3.95 && t < 4.6) || (t > 5.35 && t < 5.85))
    lit(prB, t > 5.0 && t < 8.6); show(pAllow, t > 5.0 && t < 8.6)
    lit(stB, t > 6.25 && t < 8.6, 'kf-off'); show(pDeny, t > 6.25 && t < 8.6)
    // audit
    place(dAud1, P.auditA, prog(t, 6.5, 7.9)); place(dAud2, P.auditB, prog(t, 6.7, 8.0))
  }
  update(opts.static ? 8.2 : 0)
  return { update, duration: DUR, svg }
}
