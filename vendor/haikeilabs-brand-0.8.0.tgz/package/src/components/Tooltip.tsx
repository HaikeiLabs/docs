import { Component, createMemo, createSignal, createUniqueId, JSX, Show } from 'solid-js';

export interface TooltipTriggerProps {
  'aria-describedby'?: string;
  onFocus: JSX.EventHandler<HTMLElement, FocusEvent>;
  onBlur: JSX.EventHandler<HTMLElement, FocusEvent>;
  onMouseEnter: JSX.EventHandler<HTMLElement, MouseEvent>;
  onMouseLeave: JSX.EventHandler<HTMLElement, MouseEvent>;
  onKeyDown: JSX.EventHandler<HTMLElement, KeyboardEvent>;
}

export const Tooltip: Component<{ content: string; placement?: 'top' | 'right'; disabled?: boolean; class?: string; children: (props: TooltipTriggerProps) => JSX.Element }> = (props) => {
  const id = `kei-tooltip-${createUniqueId()}`;
  const [hovered, setHovered] = createSignal(false);
  const [focused, setFocused] = createSignal(false);
  const [dismissed, setDismissed] = createSignal(false);
  const open = createMemo(() => !props.disabled && !dismissed() && (hovered() || focused()));
  const triggerProps = (): TooltipTriggerProps => ({
    get 'aria-describedby'() { return open() ? id : undefined; },
    onFocus: () => { setDismissed(false); setFocused(true); },
    onBlur: () => { setFocused(false); if (!hovered()) setDismissed(false); },
    onMouseEnter: () => { setDismissed(false); setHovered(true); },
    onMouseLeave: () => { setHovered(false); setDismissed(false); },
    onKeyDown: (event) => {
      if (event.key === 'Escape' && open()) {
        event.preventDefault();
        setDismissed(true);
      }
    },
  });
  return <span class={`kei-tooltip ${props.class ?? ''}`}>
    {props.children(triggerProps())}
    <Show when={open()}><span id={id} role="tooltip" class={`kei-tooltip-content kei-tooltip-${props.placement ?? 'top'}`}>{props.content}</span></Show>
  </span>;
};

export const TooltipHelp: Component<{ content: string; label: string }> = (props) => (
  <Tooltip content={props.content}>
    {(triggerProps) => <button {...triggerProps} type="button" aria-label={props.label} class="kei-tooltip-help">?</button>}
  </Tooltip>
);
export default Tooltip;
