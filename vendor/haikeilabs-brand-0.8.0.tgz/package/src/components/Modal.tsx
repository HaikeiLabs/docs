// Modal — brand spec v0.2 §04 (surfaces).
//
// Rewritten from the Kei frontend's API shape against design tokens. Two defects
// in that implementation are fixed here: it used shadow-xl, where §04 allows one
// shadow only (0 1px 2px rgba(0,0,0,.05)); and it referenced animate-fade-in and
// animate-scale-in, neither of which was defined anywhere in that repo, so both
// animations were silently dead. fade-in ships in components.css; the overlay
// uses it, and the panel does not animate rather than referencing a phantom.
//
// A click on the overlay closes the dialog straight away; see modal-dismiss.ts
// for why Kobalte's outside-click handling alone can drop a fast click.
import { Dialog } from '@kobalte/core/dialog'
import { Show, type JSX } from 'solid-js'
import { dismissFromOverlay } from './modal-dismiss.js'

export type ModalSize = 'sm' | 'md' | 'lg' | 'default' | 'wide'

export interface ModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  title?: string
  description?: string
  titleAccessory?: JSX.Element
  /** Panel width. Kei's version hardcoded the equivalent of `md`. */
  size?: ModalSize
  children: JSX.Element
}

const sizes: Record<ModalSize, string> = {
  sm: 'max-w-md',
  md: 'max-w-lg',
  lg: 'max-w-2xl',
  default: 'max-w-lg',
  wide: 'max-w-2xl',
}

export function Modal(props: ModalProps): JSX.Element {
  const size = () => sizes[props.size ?? 'md']

  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay
          data-kei-modal-overlay=""
          class="animate-fade-in fixed inset-0 z-50 bg-[color-mix(in_srgb,var(--color-ink)_55%,transparent)]"
          onClick={dismissFromOverlay(props)}
        />
        <Dialog.Content
          class={`surface fixed left-1/2 top-1/2 z-50 max-h-[85vh] w-full -translate-x-1/2 -translate-y-1/2 overflow-auto rounded-3xl border hairline shadow-sm ${size()}`}
        >
          <div class="p-6">
            <div class="flex items-start justify-between gap-3">
            <Show when={props.title}>
              <Dialog.Title class="text-lg font-semibold">{props.title}</Dialog.Title>
            </Show>
            <div class="flex shrink-0 items-center gap-1">{props.titleAccessory}<Dialog.CloseButton aria-label="Close dialog" class="nav-link rounded-full p-2">×</Dialog.CloseButton></div>
            </div>
            <Show when={props.description}>
              <Dialog.Description class="mt-1 text-sm text-muted">
                {props.description}
              </Dialog.Description>
            </Show>
            <div class={props.title || props.description ? 'mt-4' : ''}>{props.children}</div>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog>
  )
}

export default Modal
