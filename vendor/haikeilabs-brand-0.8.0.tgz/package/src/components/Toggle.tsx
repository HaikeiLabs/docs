import { Component } from 'solid-js';

export interface ToggleProps {
  checked: boolean;
  disabled?: boolean;
  label: string;
  onChange: (checked: boolean) => void;
}

export const Toggle: Component<ToggleProps> = (props) => (
  <button type="button" role="switch" aria-checked={props.checked} aria-label={props.label} disabled={props.disabled}
    onClick={() => props.onChange(!props.checked)}
    class={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors disabled:opacity-50 ${props.checked ? 'bg-[var(--color-accent)]' : 'bg-[var(--color-border)]'}`}>
    <span class={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${props.checked ? 'translate-x-6' : 'translate-x-1'}`} />
  </button>
);
