// Backdrop dismissal for Modal, kept free of Solid and Kobalte so it can be
// exercised in node from the built output.
//
// Kobalte's DismissableLayer arms its document pointerdown listener on a
// setTimeout(0) after the dialog mounts, so the opening click is not read as an
// outside click. When the main thread is busy right after opening, that timer
// runs late and a quick click on the backdrop is dropped: the dialog stays open.
// The overlay is a sibling of the content and covers the viewport, so a click
// whose target is the overlay itself is always outside, and a handler on it is
// live from mount.

export interface OverlayDismissProps {
  readonly open: boolean
  readonly onOpenChange: (open: boolean) => void
}

/** Returns the overlay's click handler; it closes the dialog synchronously. */
export function dismissFromOverlay(props: OverlayDismissProps): (event: Pick<Event, 'target' | 'currentTarget'>) => void {
  return (event) => {
    // A click that only bubbled up to the overlay did not land on it. When
    // Kobalte's listener was armed it has already closed the dialog on
    // pointerdown, so a second close is skipped.
    if (event.target !== event.currentTarget || !props.open) return
    props.onOpenChange(false)
  }
}
