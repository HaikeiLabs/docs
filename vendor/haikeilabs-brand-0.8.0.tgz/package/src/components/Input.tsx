// Input — brand spec v0.2 §04 (components), §07 (inputs sit recessed on dark).
//
// Rewritten from the Kei frontend's API shape against design tokens. Two a11y
// defects in that implementation are fixed here: the label was not associated
// with the input (no for/id), and the error text was not linked to it, so screen
// readers announced neither. Both are wired through a generated id.
//
// The 12px radius and the recessed --color-field background come from .field in
// components.css; on dark, --color-field is darker than the card it sits in.
import { createUniqueId, splitProps, Show, type JSX } from 'solid-js'

export interface InputProps extends JSX.InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
}

export function Input(props: InputProps): JSX.Element {
  const [local, others] = splitProps(props, ['label', 'error', 'class', 'id'])

  const generated = createUniqueId()
  const inputId = () => local.id ?? generated
  const errorId = () => `${inputId()}-error`

  return (
    <div class="grid w-full gap-2">
      <Show when={local.label}>
        <label class="field-label" for={inputId()}>
          {local.label}
        </label>
      </Show>
      <input
        id={inputId()}
        class={`field ${local.error ? 'border-[var(--color-risk-ink)]' : ''} ${local.class ?? ''}`}
        aria-invalid={local.error ? true : undefined}
        aria-describedby={local.error ? errorId() : undefined}
        {...others}
      />
      <Show when={local.error}>
        <p id={errorId()} class="risk-ink text-sm">
          {local.error}
        </p>
      </Show>
    </div>
  )
}

export default Input
