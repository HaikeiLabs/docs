// Button — brand spec v0.2 §04 (components), §07 (components on dark).
//
// Rewritten from the Kei frontend's API shape against design tokens. The shape
// (variant + size, Kobalte base) is carried over; the styling is not — that
// implementation used stock Tailwind blue/gray and relied on a runtime override
// shim to look on-brand.
//
// Variants map to the spec's three sanctioned button treatments:
//   primary   — emerald 700 fill, the one accent fill role that survives dark (§07)
//   secondary — outline; on dark it loses its fill entirely, because a white card
//               floating on ink reads as a modal rather than a button (§07)
//   dark      — the ink/nav treatment, which inverts with the theme via --color-tile
//
// NOT implemented: danger, outline, ghost. §02 admits one brand color plus amber
// for risk and warning; danger and destructive states use amber, never red, so a
// red danger button has no backing in the spec. That is a design decision for
// Claude Design, not one to invent here.
import { Button as KobalteButton } from '@kobalte/core/button'
import { splitProps, type JSX } from 'solid-js'

export type ButtonVariant = 'primary' | 'secondary' | 'dark'
export type ButtonSize = 'sm' | 'md' | 'lg'

export interface ButtonProps extends JSX.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant
  size?: ButtonSize
  children: JSX.Element
}

// The component classes in components.css already carry each variant's colors,
// radius and border. Size is the only thing layered on here.
const variants: Record<ButtonVariant, string> = {
  primary: 'button-primary',
  secondary: 'button-secondary',
  dark: 'button-dark',
}

// Buttons are pills at every size (§04: 9999px radius on buttons and pills).
const sizes: Record<ButtonSize, string> = {
  sm: 'px-4 py-2 text-sm',
  md: '',
  lg: 'px-6 py-3.5 text-base',
}

export function Button(props: ButtonProps): JSX.Element {
  const [local, others] = splitProps(props, ['variant', 'size', 'class', 'children'])

  const variant = () => local.variant ?? 'primary'
  const size = () => local.size ?? 'md'

  return (
    <KobalteButton
      class={`${variants[variant()]} ${sizes[size()]} ${local.class ?? ''}`.replace(/\s+/g, ' ').trim()}
      {...others}
    >
      {local.children}
    </KobalteButton>
  )
}

export default Button
