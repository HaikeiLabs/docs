import type { JSX } from 'solid-js'

// The Discord mark. Inherits currentColor like a lucide icon.
export interface DiscordIconProps {
  class?: string
}

export function DiscordIcon(props: DiscordIconProps): JSX.Element {
  return (
    <svg viewBox="0 0 24 24" class={props.class ?? 'size-4'} fill="currentColor" aria-hidden="true">
      <path d="M19.54 0c1.2 0 2.18.98 2.18 2.18v19.64c0 1.2-.98 2.18-2.18 2.18H4.46a2.18 2.18 0 0 1-2.18-2.18V2.18C2.28.98 3.26 0 4.46 0h15.08Zm-2.2 5.14a17.4 17.4 0 0 0-4.36-1.35l-.53 1.08a16.2 16.2 0 0 0-4.9 0l-.53-1.08a17.4 17.4 0 0 0-4.36 1.35C-.1 9.25-.87 13.26-.48 17.22a17.5 17.5 0 0 0 5.35 2.7l1.3-1.76c-.72-.26-1.4-.6-2.03-1.02l.5-.38c3.9 1.83 8.6 1.83 12.45 0l.5.38c-.63.42-1.31.76-2.03 1.02l1.3 1.76a17.5 17.5 0 0 0 5.35-2.7c.46-4.6-.79-8.57-2.84-12.08ZM8.1 15.04c-1.15 0-2.1-1.05-2.1-2.34s.92-2.34 2.1-2.34 2.1 1.05 2.1 2.34-.93 2.34-2.1 2.34Zm7.8 0c-1.15 0-2.1-1.05-2.1-2.34s.92-2.34 2.1-2.34 2.1 1.05 2.1 2.34-.92 2.34-2.1 2.34Z" />
    </svg>
  )
}

export default DiscordIcon
