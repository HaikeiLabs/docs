// Theme toggle — brand spec v0.2 §07.
//
// Dark mode follows the OS until the visitor makes an explicit choice, which is
// then persisted. The pre-paint resolution lives in scripts/theme-init.js: inline
// it in the document head so a stored dark preference does not flash light.
import { Moon, Sun } from 'lucide-solid'
import { createSignal, onCleanup, onMount, type JSX } from 'solid-js'

const STORAGE_KEY = 'haikei-theme'

export type Theme = 'light' | 'dark'

/**
 * Resolve the theme without touching the DOM: an explicit stored choice if there
 * is one, otherwise the OS preference. Mirrors scripts/theme-init.js.
 */
export function initialTheme(): Theme {
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored === 'dark' || stored === 'light') return stored
  } catch {
    // Private browsing or blocked storage: fall back to the OS preference.
  }
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
}

export interface ThemeToggleProps {
  class?: string
}

export function ThemeToggle(props: ThemeToggleProps): JSX.Element {
  const [theme, setTheme] = createSignal<Theme>('light')

  onMount(() => {
    setTheme(document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light')

    // Follow the OS while the visitor has not made an explicit choice.
    const media = window.matchMedia('(prefers-color-scheme: dark)')
    const onChange = (event: MediaQueryListEvent) => {
      try {
        if (localStorage.getItem(STORAGE_KEY)) return
      } catch {
        /* storage unavailable: keep following the OS */
      }
      apply(event.matches ? 'dark' : 'light')
    }
    media.addEventListener('change', onChange)

    // onMount ignores returned functions, so the listener has to be torn down
    // through onCleanup or it outlives the component.
    onCleanup(() => media.removeEventListener('change', onChange))
  })

  function apply(next: Theme) {
    setTheme(next)
    document.documentElement.dataset.theme = next
  }

  function toggle() {
    const next: Theme = theme() === 'dark' ? 'light' : 'dark'
    apply(next)
    try {
      localStorage.setItem(STORAGE_KEY, next)
    } catch {
      /* choice is not persisted, but the page still switches */
    }
  }

  const label = () => (theme() === 'dark' ? 'Switch to light theme' : 'Switch to dark theme')

  return (
    <button
      class={`nav-link grid size-9 place-items-center rounded-full transition hover:bg-[color-mix(in_srgb,var(--color-content)_8%,transparent)] ${props.class ?? ''}`}
      type="button"
      onClick={toggle}
      aria-label={label()}
      title={label()}
    >
      {theme() === 'dark' ? <Sun class="size-4" /> : <Moon class="size-4" />}
    </button>
  )
}

export default ThemeToggle
