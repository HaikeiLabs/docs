// Card — brand spec v0.2 §04 (surfaces).
//
// Rewritten from the Kei frontend's API shape against design tokens. Radius is
// 24px per §04 (16/24px cards), the border is a themed hairline, and the shadow
// is the single sanctioned one — 0 1px 2px rgba(0,0,0,.05), which .surface and
// shadow-sm already carry. No layered or colored shadows.
import { splitProps, Show, type JSX } from 'solid-js'

export interface CardProps extends JSX.HTMLAttributes<HTMLDivElement> {
  title?: string
  description?: string
  headerAction?: JSX.Element
  /**
   * Drop the body padding. Kei's version had no escape hatch, so a card could
   * not host a full-bleed table.
   */
  padding?: 'default' | 'none'
}

export function Card(props: CardProps): JSX.Element {
  const [local, others] = splitProps(props, ['title', 'description', 'headerAction', 'padding', 'class', 'children'])

  const hasHeader = () => Boolean(local.title || local.description || local.headerAction)
  const bodyPadding = () => (local.padding === 'none' ? '' : 'px-6 py-5')

  return (
    <div
      class={`surface rounded-3xl border hairline shadow-sm ${local.class ?? ''}`}
      {...others}
    >
      <Show when={hasHeader()}>
        <div class="border-b hairline px-6 py-4 flex items-center justify-between gap-4">
          <div>
          <Show when={local.title}>
            <h3 class="text-lg font-semibold">{local.title}</h3>
          </Show>
          <Show when={local.description}>
            <p class="mt-1 text-sm text-muted">{local.description}</p>
          </Show>
          </div>
          <Show when={local.headerAction}><div class="shrink-0">{local.headerAction}</div></Show>
        </div>
      </Show>
      <div class={bodyPadding()}>{local.children}</div>
    </div>
  )
}

export default Card
