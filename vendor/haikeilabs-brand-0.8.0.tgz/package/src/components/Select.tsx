import { Component, createEffect, createUniqueId, JSX, splitProps } from 'solid-js';

export interface SelectProps extends JSX.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  wrapperClass?: string;
}

export const Select: Component<SelectProps> = (props) => {
  const [local, others] = splitProps(props, ['label', 'error', 'class', 'wrapperClass', 'id', 'children', 'value', 'onChange']);
  const generatedId = createUniqueId();
  const selectId = () => local.id ?? generatedId;
  const errorId = () => local.error ? `${selectId()}-error` : undefined;

  let selectElement: HTMLSelectElement | undefined;
  createEffect(() => {
    const value = local.value;
    if (!selectElement || value == null) return;
    if (Array.isArray(value)) {
      const selected = new Set(value.map(String));
      for (const option of selectElement.options) option.selected = selected.has(option.value);
    } else {
      selectElement.value = String(value);
    }
  });

  return (
    <div class={`w-full space-y-1 ${local.wrapperClass || ''}`}>
      {local.label && (
        <label for={selectId()} class="field-label">
          {local.label}
        </label>
      )}
      <div class="relative w-full">
        <select
          ref={(element) => { selectElement = element; }}
          id={selectId()}
          aria-describedby={errorId()}
          aria-invalid={local.error ? true : undefined}
          value={local.value}
          onChange={local.onChange}
          class={`field block w-full appearance-none pr-10 ${
            local.error ? 'border-[var(--color-risk-ink)]' : ''
          } ${local.class || ''}`}
          {...others}
        >
          {local.children}
        </select>
        <svg aria-hidden="true" viewBox="0 0 20 20" fill="none" class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500">
          <path d="m5 7.5 5 5 5-5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
      </div>
      {local.error && (
        <p id={errorId()} class="risk-ink text-sm">{local.error}</p>
      )}
    </div>
  );
};
