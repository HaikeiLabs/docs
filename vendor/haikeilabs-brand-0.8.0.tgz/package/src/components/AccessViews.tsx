import { For, Show, splitProps, type JSX } from 'solid-js'

export type Effect = 'permit' | 'deny'

export interface EffectPillProps extends JSX.HTMLAttributes<HTMLSpanElement> {
  effect: Effect
}

export function EffectPill(props: EffectPillProps): JSX.Element {
  const [local, rest] = splitProps(props, ['effect', 'class', 'children'])
  return <span class={`effect-pill effect-pill-${local.effect} ${local.class ?? ''}`} {...rest}>
    <span class="effect-pill-dot" aria-hidden="true" />{local.children ?? local.effect}
  </span>
}

export interface StatusDotProps extends JSX.HTMLAttributes<HTMLSpanElement> { enabled: boolean }
export function StatusDot(props: StatusDotProps): JSX.Element {
  const [local, rest] = splitProps(props, ['enabled', 'class', 'children'])
  return <span class={`status-dot ${local.enabled ? 'status-dot-enabled' : 'status-dot-disabled'} ${local.class ?? ''}`} {...rest}>
    <span class="status-dot-mark" aria-hidden="true" />{local.children ?? (local.enabled ? 'Enabled' : 'Disabled')}
  </span>
}

export interface PatternTagProps extends JSX.HTMLAttributes<HTMLSpanElement> { value: string }
export function PatternTag(props: PatternTagProps): JSX.Element {
  const [local, rest] = splitProps(props, ['value', 'class'])
  const split = () => {
    const colon = local.value.indexOf(':')
    return colon < 0 ? [undefined, local.value] as const : [local.value.slice(0, colon + 1), local.value.slice(colon + 1)] as const
  }
  return <span class={`pattern-tag ${local.class ?? ''}`} title={local.value} aria-label={local.value} {...rest}>
    <Show when={split()[0]}>{(prefix) => <span class="pattern-tag-prefix">{prefix()}</span>}</Show>
    <span class="pattern-tag-value">{split()[1]}</span>
  </span>
}

export interface OriginTagProps extends JSX.HTMLAttributes<HTMLSpanElement> { origin: string }
export function OriginTag(props: OriginTagProps): JSX.Element {
  const [local, rest] = splitProps(props, ['origin', 'class'])
  const kind = () => local.origin === 'direct' ? 'direct' : local.origin.startsWith('via ') ? 'via' : 'global'
  return <span class={`origin-tag origin-tag-${kind()} ${local.class ?? ''}`} {...rest}>{local.origin}</span>
}

export interface AvatarUser { initials: string; name?: string }
export interface AvatarStackProps extends JSX.HTMLAttributes<HTMLDivElement> { users: AvatarUser[] }
export function AvatarStack(props: AvatarStackProps): JSX.Element {
  const [local, rest] = splitProps(props, ['users', 'class'])
  return <div class={`avatar-stack ${local.class ?? ''}`} role="group" aria-label={`${local.users.length} users`} {...rest}>
    <For each={local.users}>{(user, index) => <span class="avatar-stack-item" style={{ '--avatar-index': index() % 5 }} title={user.name ?? user.initials} aria-label={user.name ?? user.initials}>{user.initials}</span>}</For>
  </div>
}

export interface SegmentOption { value: string; label: string }
export interface SegmentedControlProps extends Omit<JSX.HTMLAttributes<HTMLDivElement>, 'onChange'> {
  options: SegmentOption[]
  value: string
  onChange?: (value: string) => void
  ariaLabel?: string
}
export function SegmentedControl(props: SegmentedControlProps): JSX.Element {
  const [local, rest] = splitProps(props, ['options', 'value', 'onChange', 'ariaLabel', 'class'])
  return <div class={`segmented-control ${local.class ?? ''}`} role="group" aria-label={local.ariaLabel} {...rest}>
    <For each={local.options}>{(option) => <button type="button" class={`segmented-control-option ${local.value === option.value ? 'is-active' : ''}`} aria-pressed={local.value === option.value} onClick={() => local.onChange?.(option.value)}>{option.label}</button>}</For>
  </div>
}

export interface FilterChipProps extends JSX.ButtonHTMLAttributes<HTMLButtonElement> { selected: boolean }
export function FilterChip(props: FilterChipProps): JSX.Element {
  const [local, rest] = splitProps(props, ['selected', 'class', 'children'])
  return <button type="button" class={`filter-chip ${local.selected ? 'is-selected' : ''} ${local.class ?? ''}`} aria-pressed={local.selected} {...rest}>{local.children}</button>
}
