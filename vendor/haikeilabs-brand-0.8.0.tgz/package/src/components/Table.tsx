// Table and Pagination — brand spec v0.2 §03 (eyebrow labels), §04 (surfaces).
//
// Rewritten from the Kei frontend's API shape against design tokens. Two defects
// in that implementation are fixed here:
//   - keyField was a required prop that was never used, so rows were keyed by
//     index and Solid could not track them across reorders. It now keys the rows.
//   - Pagination rendered every page number with no truncation, which blows up on
//     large datasets. It now windows around the current page with ellipses.
//
// Column headers use the eyebrow treatment (§03: JetBrains Mono 500, +0.18em) via
// the .eyebrow class rather than a hand-rolled bold sans equivalent.
import { For, Show, type JSX } from 'solid-js'

export interface Column<T> {
  key: keyof T | string
  header: string
  render?: (item: T) => JSX.Element
}

export interface TableProps<T> {
  data: T[]
  columns: Column<T>[]
  /** Field whose value uniquely identifies a row. Used to key the rows. */
  keyField: keyof T
  loading?: boolean
  emptyMessage?: string
  onRowClick?: (item: T) => void
}

export function Table<T>(props: TableProps<T>): JSX.Element {
  const colCount = () => props.columns.length

  return (
    <div class="overflow-x-auto">
      <table class="min-w-full border-collapse">
        <thead>
          <tr class="border-b hairline">
            <For each={props.columns}>
              {(col) => <th class="eyebrow px-6 py-3 text-left">{col.header}</th>}
            </For>
          </tr>
        </thead>
        <tbody>
          <Show
            when={!props.loading}
            fallback={
              <tr>
                <td colspan={colCount()} class="px-6 py-8 text-center text-muted">
                  Loading…
                </td>
              </tr>
            }
          >
            <Show
              when={props.data.length > 0}
              fallback={
                <tr>
                  <td colspan={colCount()} class="px-6 py-8 text-center text-muted">
                    {props.emptyMessage ?? 'No data'}
                  </td>
                </tr>
              }
            >
              {/* Keyed by keyField so rows survive reordering. */}
              <For each={props.data}>
                {(item) => (
                  <tr
                    class={`border-b hairline transition ${props.onRowClick ? 'cursor-pointer hover:bg-[var(--color-surface-hover)]' : ''}`}
                    onClick={() => props.onRowClick?.(item)}
                  >
                    <For each={props.columns}>
                      {(col) => (
                        <td class="px-6 py-4 text-sm">
                          {col.render ? col.render(item) : String(item[col.key as keyof T] ?? '')}
                        </td>
                      )}
                    </For>
                  </tr>
                )}
              </For>
            </Show>
          </Show>
        </tbody>
      </table>
    </div>
  )
}

export interface PaginationProps {
  page: number
  pageSize: number
  total: number
  onPageChange: (page: number) => void
  /** Page links to show either side of the current page. */
  siblings?: number
}

/**
 * Page numbers to render, with `null` marking an elided run. Kei's version
 * listed every page, so a large dataset produced hundreds of links.
 */
function pageItems(current: number, last: number, siblings: number): (number | null)[] {
  // First, last, current, and `siblings` on each side, plus a slot for each gap.
  if (last <= siblings * 2 + 5) {
    return Array.from({ length: last }, (_, i) => i + 1)
  }

  const items: (number | null)[] = [1]
  const start = Math.max(2, current - siblings)
  const end = Math.min(last - 1, current + siblings)

  if (start > 2) items.push(null)
  for (let p = start; p <= end; p++) items.push(p)
  if (end < last - 1) items.push(null)

  items.push(last)
  return items
}

export function Pagination(props: PaginationProps): JSX.Element {
  const lastPage = () => Math.max(1, Math.ceil(props.total / props.pageSize))
  const items = () => pageItems(props.page, lastPage(), props.siblings ?? 1)

  return (
    <Show when={lastPage() > 1}>
      <nav class="flex items-center justify-center gap-1 py-4" aria-label="Pagination">
        <button
          type="button"
          class="nav-link rounded-full px-3 py-1.5 text-sm disabled:opacity-40"
          disabled={props.page <= 1}
          onClick={() => props.onPageChange(props.page - 1)}
        >
          Previous
        </button>
        <For each={items()}>
          {(item) =>
            item === null ? (
              <span class="px-2 text-sm text-faint" aria-hidden="true">
                …
              </span>
            ) : (
              <button
                type="button"
                class={`rounded-full px-3 py-1.5 text-sm transition ${
                  item === props.page
                    ? 'bg-[var(--color-accent)] font-semibold text-[var(--color-on-accent)]'
                    : 'nav-link'
                }`}
                aria-current={item === props.page ? 'page' : undefined}
                onClick={() => props.onPageChange(item)}
              >
                {item}
              </button>
            )
          }
        </For>
        <button
          type="button"
          class="nav-link rounded-full px-3 py-1.5 text-sm disabled:opacity-40"
          disabled={props.page >= lastPage()}
          onClick={() => props.onPageChange(props.page + 1)}
        >
          Next
        </button>
      </nav>
    </Show>
  )
}

export default Table
