// Primary mark — brand spec v0.2 §01 (spec/Haikei Design Spec.dc.html).
//
// Two planes overlap. The back plane is the raw context (the haikei); the front
// plane is the policy boundary. What is governed is what sits inside both: four
// data points knocked out of a solid intersection.
//
// The rule that governs every other logo decision: the square behind the mark is
// always the page ground — never a chip in the opposite color. So the knocked-out
// points take the ground color, and this component never draws its own backdrop.
//
// Below 24px the four points go to mud, so the spec calls for a reduced mark:
// one plane, one point. Pass a `size` under 24 and that is what renders.
import type { JSX } from 'solid-js'

export interface LogoProps {
  /** Rendered width and height in px. Below 24 switches to the reduced mark. */
  size?: number
  /**
   * Force a colorway instead of following the page theme. Use on a permanently
   * dark or light ground, where the theme tokens would resolve to the wrong one.
   */
  tone?: 'ink' | 'light'
  class?: string
}

export function Logo(props: LogoProps): JSX.Element {
  const size = () => props.size ?? 32
  const forced = () => props.tone

  const plane = () => (forced() === 'ink' ? '#6ee7b7' : forced() === 'light' ? '#047857' : 'var(--logo-plane)')
  const front = () => (forced() === 'ink' ? '#ffffff' : forced() === 'light' ? '#07110d' : 'var(--logo-front)')
  const point = () => (forced() === 'ink' ? '#07110d' : forced() === 'light' ? '#ffffff' : 'var(--logo-point)')

  return (
    <svg
      width={size()}
      height={size()}
      viewBox="0 0 32 32"
      role="img"
      aria-label="Haikei Labs"
      class={props.class}
    >
      {size() < 24 ? (
        <>
          <rect x="3" y="3" width="26" height="26" rx="3" fill="none" stroke={front()} stroke-width="3.2" />
          <circle cx="16" cy="16" r="4.6" fill={plane()} />
        </>
      ) : (
        <>
          <rect x="9.5" y="9.5" width="13" height="13" rx="1.4" fill={plane()} />
          <rect x="1" y="1" width="21.5" height="21.5" rx="2.2" fill="none" stroke={plane()} stroke-width="2.1" />
          <rect x="9.5" y="9.5" width="21.5" height="21.5" rx="2.2" fill="none" stroke={front()} stroke-width="2.1" />
          <circle cx="13.3" cy="13.3" r="1.65" fill={point()} />
          <circle cx="18.7" cy="13.3" r="1.65" fill={point()} />
          <circle cx="13.3" cy="18.7" r="1.65" fill={point()} />
          <circle cx="18.7" cy="18.7" r="1.65" fill={point()} />
        </>
      )}
    </svg>
  )
}

export default Logo
