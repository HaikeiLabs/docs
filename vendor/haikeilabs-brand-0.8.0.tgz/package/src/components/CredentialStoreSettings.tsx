import { For, Show, createUniqueId, splitProps, type JSX } from 'solid-js'

export type CredentialStoreScope = 'organization' | 'workspace'
export type CredentialStoreBackend = 'aws-secrets-manager' | 'azure-key-vault' | 'gcp-secret-manager'

export interface CredentialStoreWorkspace {
  id: string
  name: string
}

export interface CredentialStoreBackendConfig {
  accountId?: string
  region?: string
  keyVaultUri?: string
  projectId?: string
}

export interface CredentialStoreSettingsProps extends JSX.HTMLAttributes<HTMLDivElement> {
  scope: CredentialStoreScope
  onScopeChange?: (scope: CredentialStoreScope) => void
  workspaces?: CredentialStoreWorkspace[]
  workspaceId?: string
  onWorkspaceChange?: (workspaceId: string) => void
  backend: CredentialStoreBackend
  onBackendChange: (backend: CredentialStoreBackend) => void
  backendConfig?: CredentialStoreBackendConfig
  onBackendConfigChange?: (config: CredentialStoreBackendConfig) => void
  secretNamePrefix: string
  onSecretNamePrefixChange: (prefix: string) => void
  enabled: boolean
  onEnabledChange: (enabled: boolean) => void
  hasWorkspaceOverride?: boolean
  onRemoveOverride?: () => void
}

const backendOptions: { value: CredentialStoreBackend; label: string }[] = [
  { value: 'aws-secrets-manager', label: 'AWS Secrets Manager' },
  { value: 'azure-key-vault', label: 'Azure Key Vault' },
  { value: 'gcp-secret-manager', label: 'GCP Secret Manager' },
]

export function CredentialStoreSettings(props: CredentialStoreSettingsProps): JSX.Element {
  const [local, rest] = splitProps(props, [
    'scope', 'onScopeChange', 'workspaces', 'workspaceId', 'onWorkspaceChange',
    'backend', 'onBackendChange', 'backendConfig', 'onBackendConfigChange',
    'secretNamePrefix', 'onSecretNamePrefixChange', 'enabled', 'onEnabledChange',
    'hasWorkspaceOverride', 'onRemoveOverride', 'class',
  ])
  const prefixHelpId = `credential-store-prefix-help-${createUniqueId()}`
  const updateConfig = (key: keyof CredentialStoreBackendConfig, value: string) =>
    local.onBackendConfigChange?.({ ...local.backendConfig, [key]: value })

  return <div class={`credential-store-settings ${local.class ?? ''}`} {...rest}>
    <header class="credential-store-settings-header">
      <h2 class="credential-store-settings-title">Credential store</h2>
      <Show when={local.onScopeChange} fallback={<p class="credential-store-settings-field"><span>Scope</span><span>{local.scope === 'organization' ? 'Organization default' : 'Workspace override'}</span></p>}>
      <label class="credential-store-settings-field">
        <span>Scope</span>
        <select aria-label="Scope" value={local.scope} onChange={(event) => local.onScopeChange?.(event.currentTarget.value as CredentialStoreScope)}>
          <option value="organization">Organization default</option>
          <option value="workspace">Workspace override</option>
        </select>
      </label>
      </Show>
    </header>

    <Show when={local.scope === 'workspace'}>
      <label class="credential-store-settings-field">
        <span>Workspace</span>
        <select aria-label="Workspace" value={local.workspaceId ?? ''} onChange={(event) => local.onWorkspaceChange?.(event.currentTarget.value)}>
          <option value="">Select a workspace</option>
          <For each={local.workspaces ?? []}>{(workspace) => <option value={workspace.id}>{workspace.name}</option>}</For>
        </select>
      </label>
      <p class="credential-store-settings-help">A workspace override takes precedence over the organization default. Disable it to keep the override without applying it, or remove it to use the organization default.</p>
    </Show>

    <div class="credential-store-settings-grid">
      <label class="credential-store-settings-field">
        <span>Backend</span>
        <select aria-label="Backend" value={local.backend} onChange={(event) => local.onBackendChange(event.currentTarget.value as CredentialStoreBackend)}>
          <For each={backendOptions}>{(option) => <option value={option.value}>{option.label}</option>}</For>
        </select>
      </label>
      <label class="credential-store-settings-field">
        <span>Secret name prefix</span>
        <input aria-label="Secret name prefix" aria-describedby={prefixHelpId} required value={local.secretNamePrefix} onInput={(event) => local.onSecretNamePrefixChange(event.currentTarget.value)} />
        <span id={prefixHelpId} class="credential-store-settings-help">Prefix used for secret names in the credential store.</span>
      </label>
    </div>

    <Show when={local.backend === 'aws-secrets-manager'}>
      <div class="credential-store-settings-grid">
        <label class="credential-store-settings-field"><span>AWS account ID</span><input aria-label="AWS account ID" required value={local.backendConfig?.accountId ?? ''} onInput={(event) => updateConfig('accountId', event.currentTarget.value)} /></label>
        <label class="credential-store-settings-field"><span>AWS region</span><input aria-label="AWS region" required value={local.backendConfig?.region ?? ''} onInput={(event) => updateConfig('region', event.currentTarget.value)} /></label>
      </div>
    </Show>
    <Show when={local.backend === 'azure-key-vault'}>
      <label class="credential-store-settings-field"><span>Key Vault URI</span><input aria-label="Key Vault URI" required value={local.backendConfig?.keyVaultUri ?? ''} onInput={(event) => updateConfig('keyVaultUri', event.currentTarget.value)} /></label>
    </Show>
    <Show when={local.backend === 'gcp-secret-manager'}>
      <label class="credential-store-settings-field"><span>Project ID</span><input aria-label="Project ID" required value={local.backendConfig?.projectId ?? ''} onInput={(event) => updateConfig('projectId', event.currentTarget.value)} /></label>
    </Show>

    <label class="credential-store-settings-toggle"><input type="checkbox" checked={local.enabled} onChange={(event) => local.onEnabledChange(event.currentTarget.checked)} /> Enabled</label>
    <Show when={local.scope === 'workspace' && local.hasWorkspaceOverride && local.onRemoveOverride}>
      <button type="button" class="button-secondary credential-store-settings-remove" onClick={() => local.onRemoveOverride?.()}>Remove override</button>
    </Show>
  </div>
}
