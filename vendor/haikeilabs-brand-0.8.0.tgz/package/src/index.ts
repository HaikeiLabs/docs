// @haikei/brand — Haikei Labs design system components.
//
// Styles are NOT imported here: CSS is a separate entry point so non-Solid
// consumers (decks, documents, plain HTML) can take the tokens without pulling
// in a framework. Import "@haikei/brand/index.css" alongside these.
//
// Not exported: Badge/StatusPill. Three ad-hoc implementations exist downstream,
// but the spec does not define one — it needs a design decision before it ships.

export { Logo, type LogoProps } from './components/Logo.js'
export { ThemeToggle, initialTheme, type ThemeToggleProps, type Theme } from './components/ThemeToggle.js'
export { GithubIcon, type GithubIconProps } from './components/GithubIcon.js'
export { DiscordIcon, type DiscordIconProps } from './components/DiscordIcon.js'
export { Button, type ButtonProps, type ButtonVariant, type ButtonSize } from './components/Button.js'
export { Card, type CardProps } from './components/Card.js'
export { Input, type InputProps } from './components/Input.js'
export { Modal, type ModalProps, type ModalSize } from './components/Modal.js'
export { Table, Pagination, type TableProps, type PaginationProps, type Column } from './components/Table.js'
export { EffectPill, StatusDot, PatternTag, OriginTag, AvatarStack, SegmentedControl, FilterChip, type Effect, type EffectPillProps, type StatusDotProps, type PatternTagProps, type OriginTagProps, type AvatarUser, type AvatarStackProps, type SegmentOption, type SegmentedControlProps, type FilterChipProps } from './components/AccessViews.js'
export { CredentialStoreSettings, type CredentialStoreSettingsProps, type CredentialStoreScope, type CredentialStoreBackend, type CredentialStoreBackendConfig, type CredentialStoreWorkspace } from './components/CredentialStoreSettings.js'

// Framework-free motion (§04). Also published as standalone subpaths
// (@haikeilabs/brand/hero-field.js, /kei-flow.js) for pages without Solid.
export { mountHeroField, type HeroFieldOptions } from './motion/hero-field.js'
export { KeiFlow, type KeiFlowOptions, type KeiFlowInstance } from './motion/kei-flow.js'

export { Select, type SelectProps } from './components/Select.js'
export { Toggle, type ToggleProps } from './components/Toggle.js'
export { Tooltip, TooltipHelp, type TooltipTriggerProps } from './components/Tooltip.js'
