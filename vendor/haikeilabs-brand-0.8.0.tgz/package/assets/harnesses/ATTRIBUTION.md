# Harness mark attribution

These third-party marks are used nominatively to indicate compatibility with the
listed products and services. Their presence does not imply endorsement,
sponsorship, or affiliation with Haikei Labs.

| File | Represents | Source |
| --- | --- | --- |
| `anthropic.svg` | Claude Code / Anthropic | [Simple Icons](https://simpleicons.org/), CC0 1.0 Universal |
| `openai.svg` | Codex / OpenAI | [Simple Icons](https://simpleicons.org/), CC0 1.0 Universal |
| `opencode.svg` | OpenCode | [Simple Icons](https://simpleicons.org/), CC0 1.0 Universal |
| `cursor.svg` | Cursor | [Simple Icons](https://simpleicons.org/), CC0 1.0 Universal |
| `discord.svg` | Discord | [Simple Icons](https://simpleicons.org/), CC0 1.0 Universal |
| `pi.svg` | Pi | Original typographic pi glyph drawn for this asset; no official project mark identified |

The Simple Icons paths are reproduced from the corresponding marks in the
`simple-icons` project, whose icons are dedicated to the public domain under CC0.
The Pi glyph is a plain typographic compatibility indicator.

Use these marks only to identify supported integrations. Do not alter their shapes,
recolor them beyond monochrome rendering, or use them in a way that implies
endorsement. `currentColor` is used so consumers can render each mark in a single,
accessible foreground color for either theme.
