# Partner badge attribution

These third-party badges indicate Haikei Labs' membership in the listed partner
programs. They indicate **program membership only**. Their presence does not imply
endorsement, sponsorship, certification, or any other affiliation with Haikei Labs
beyond that membership.

| File | Represents | Source |
| --- | --- | --- |
| `nvidia-inception-program-badge-rgb-for-screen.svg` | NVIDIA Inception Program member badge, full colour (white panel inside a black frame, NVIDIA Green `#76b900`) | NVIDIA Inception member badge pack, "for screen" RGB artwork |
| `nvidia-inception-program-badge-rgb-for-screen.png` | Raster of the full-colour badge, 501 × 217 | NVIDIA Inception member badge pack, "for screen" RGB artwork |
| `nvidia-inception-program-badge-rgb-1c-blk-for-screen.svg` | NVIDIA Inception Program member badge, one-colour black | NVIDIA Inception member badge pack, "for screen" one-colour artwork |
| `nvidia-inception-program-badge-rgb-1c-blk-for-screen.png` | Raster of the one-colour badge, 501 × 217 | NVIDIA Inception member badge pack, "for screen" one-colour artwork |

The files are reproduced byte-for-byte from NVIDIA's pack. Do not edit, optimise,
re-export or re-encode them; replace them only with a newer official pack.

## NVIDIA usage rules

- **Prefer the full-colour badge.** It carries its own white panel, so it works on
  both light and dark backgrounds. There is no reversed version — do not make one.
- **Use the one-colour black badge only when full-colour reproduction is not
  possible.**
- **Never change** the colours (`#76b900`, black, white), the proportions or the
  text. Do not recolour to a brand token, theme with `currentColor`, stretch, crop,
  outline or add effects.
- **Never write the program name in all caps.** It is "NVIDIA Inception Program".
- **The badge must never be bigger than the Haikei logo** it appears with.
- **Clear space:** keep at least the badge's own frame margin clear on every side —
  the band between the artboard edge and the black frame, about 5% of the badge
  width (6px at the minimum size). The files include that band; never crop it, and
  keep other content outside it.
- **Minimum size:** 120px wide on screen.
- **Legal line.** Place this line next to the badge, in sentence case:

  > © 2026 NVIDIA and the NVIDIA logo are trademarks and/or registered trademarks of
  > NVIDIA Corporation in the U.S. and other countries.

NVIDIA Green `#76b900` is a third-party colour inside these files. It is not a Haikei
token and must not be used anywhere else in Haikei work.
