# Vendored package distribution

`@haikeilabs/brand` is distributed as a tarball committed to each consumer repository. CodeArtifact and registry credentials are not used. Consumers install their ordinary dependencies from npm as usual; the brand package comes from `vendor/`.

## Release and upgrade

1. Bump the version in `package.json` and `package-lock.json`, add a CHANGELOG entry, run `npm run build` and `npm test`, and merge the change to main.
2. From a checkout of this repository, run for each consumer:

   ```bash
   node scripts/vendor-into.mjs /path/to/consumer --ref main
   ```

   Use a stable commit or tag instead of `main` when an exact revision is needed. Omit `--ref` to build the current working tree, including uncommitted changes. The script builds and packs the package, replaces older brand tarballs in the consumer's `vendor/` directory, and updates its dependency to `file:vendor/haikeilabs-brand-X.Y.Z.tgz`.
3. In the consumer, run `npm install`, run its checks, and commit the tarball, package manifest, and lockfile in an upgrade PR. The script does not install consumer dependencies.

## Roll back

Re-run the script with `--ref` pointing to the previous release's commit or tag, then run `npm install` in the consumer and commit the resulting tarball, manifest, and lockfile in a rollback PR.

The package has peer dependencies on Solid, Kobalte, and lucide-solid. `npm test` verifies its packed exports and a Solid/Vite/Tailwind consumer build.
