# Haikei Labs design system

The brand and design specification, authored in Claude Design, and the
`@haikeilabs/brand` package that implements it. **This repo is the source of truth for
anything visual** — colors, typography, spacing, the logo, dark mode, and the rules
for their use. Haikei is the sovereign context framework: build and run agents while
you keep your own models and your own data. Our voice is Sage + Creator: precise,
practical, and builders enabling builders. See [messaging and terminology](docs/messaging.md).

## Install

```bash
node scripts/vendor-into.mjs /path/to/consumer --ref main
# Then in the consumer:
npm install
```

```css
/* Tailwind v4 stays the consumer's — the package never imports it. */
@import "tailwindcss";
@import "@haikeilabs/brand/index.css";
```

```tsx
import { Logo, Button, ThemeToggle } from '@haikeilabs/brand'

<Logo size={32} />              // follows the page theme
<Button variant="primary">Become a beta partner</Button>
```

Inline `@haikeilabs/brand/theme-init.js` in the document head, before any stylesheet, so a
stored dark preference does not flash light.

### Entry points

| Import | What |
| --- | --- |
| `@haikeilabs/brand` | Components (Solid) |
| `@haikeilabs/brand/index.css` | Tokens + base + component classes |
| `@haikeilabs/brand/tokens.css` | Tokens only |
| `@haikeilabs/brand/base.css` | Base styles |
| `@haikeilabs/brand/components.css` | Component classes |
| `@haikeilabs/brand/modern.css` | The Modern layer (§10) — opt-in via `[data-style="modern"]` |
| `@haikeilabs/brand/modern.js` | Modern layer behaviors: circle cursor, copyable command |
| `@haikeilabs/brand/hero-field.js` | `mountHeroField(host)` — the connected-dots hero field (§04), framework-free |
| `@haikeilabs/brand/kei-flow.js` | `KeiFlow(el, { static })` — the How it works animation (§04), framework-free |
| `@haikeilabs/brand/kei-flow.css` | Styles for `KeiFlow` (scoped to `.kflow`) |
| `@haikeilabs/brand/tokens.json` | Tokens as data |
| `@haikeilabs/brand/fonts.css` | Inter + JetBrains Mono |
| `@haikeilabs/brand/theme-init.js` | Pre-paint theme resolution |
| `@haikeilabs/brand/assets/logo/…` | Logo and lockup files |
| `@haikeilabs/brand/assets/harnesses/…` | Monochrome coding-harness compatibility marks (SVG) |
| `@haikeilabs/brand/assets/partners/…` | NVIDIA Inception Program member badges (SVG + PNG, unmodified) |
| `@haikeilabs/brand/assets/favicon/…` | Favicons |
| `@haikeilabs/brand/guidelines/…` | The rules, as markdown |

Harness marks are available as SVG files. For example, import
`@haikeilabs/brand/assets/harnesses/anthropic.svg` or copy files from the package's
`assets/harnesses/` directory into a consumer's static assets. Their SVG fill uses
`currentColor`, so set the CSS `color` for the intended theme.

## Distribution and version policy

Commit the generated tarball and lockfile in each consumer. Releases and rollbacks
re-vendor a chosen revision; no CodeArtifact or registry credentials are used.
See [the distribution runbook](docs/publication.md).

## Components

`Logo` · `ThemeToggle` · `GithubIcon` · `DiscordIcon` · `Button` · `Card` · `Input` · `Modal` ·
`Select` · `Toggle` · `Tooltip` · `Table` + `Pagination` · `EffectPill` · `StatusDot` · `PatternTag` · `OriginTag` ·
`AvatarStack` · `SegmentedControl` · `FilterChip` · `CredentialStoreSettings`

`CredentialStoreSettings` is a presentational control for organization defaults and
workspace overrides. It accepts controlled values and callbacks; the consuming
application owns data loading and persistence. See [Credential store settings](docs/credential-store-settings.md).

Access view components are presentational Solid components for Kei policy and audit
interfaces. Import them from `@haikeilabs/brand`; import their styles from
`@haikeilabs/brand/index.css` (or use the individual `components.css` entry). The permit and deny decision tokens are also available from `@haikeilabs/brand/tokens.css` and `tokens.json`.
See [Access view components](docs/access-view-components.md) for props and examples.

Not shipped, pending a design decision: `Badge`/`StatusPill`, and the
`danger`/`outline`/`ghost` button variants; the package does ship risk tokens.
The `--color-risk-*` tokens are amber in both themes — danger and destructive
states use amber, never red. The package also exports `--kei-permit-*` and
`--kei-deny-*` tokens. `--color-accent-soft` has no
dark override and therefore retains its light value in dark mode.

## The Modern layer

An opt-in visual layer for launch pages, campaign surfaces, and developer-facing
hero moments (spec §10, hand-authored from the approved onboarding study). Set
`data-style="modern"` on a page or any wrapper: the section turns dark-first
(§07 palette), display headlines go very large and tightly tracked with one
italic accent span, and nav/buttons take a mono uppercase treatment at 8px
corners. Components: stats row, copyable command, ticker, retro window. It adds
no colors — its token block is a machine-checked mirror of the §07 dark block.
Import `modern.css` (included in `index.css`) and, for the circle cursor and the
copy behavior, `modern.js`. Rules and markup: [guidelines/10-modern.md](guidelines/10-modern.md).

## The spec

`spec/Haikei Design Spec.dc.html` — v0.2, September 2026. Open it from a local server,
not `file://`:

```bash
cd spec && python3 -m http.server 8000
```

Sections: 01 Logo · 02 Color · 03 Typography · 04 Website · 05 Slides ·
06 Documents & print · 07 Dark mode. `guidelines/` carries the same rules as markdown,
derived from the spec.

## What v0.2 changed

- **§07 Dark mode** was added. Not a filter over light: ink becomes the page ground,
  and emerald 700 stops carrying text — mint 300 takes over every text, link, icon and
  eyebrow role, because **emerald 700 on ink measures 3.50:1** and fails WCAG AA.
  Emerald 700 keeps only its solid-fill jobs. Mint on ink measures 12.58:1.
- **The logo rule that governs every other logo decision:** the square behind the mark
  is always the page ground — white in light, ink in dark. Never a chip in the opposite
  color.
- The mark is a **filled overlap with four data points knocked out to the ground**, and
  gains a **reduced form below 24px** (one plane, one point) where four points go to mud.

## Development

```bash
npm test         # build, spec checks, packed consumer build, release guards
npm run check    # drift, contrast and design-card checks
npm run build    # tsc declarations + dist/styles.flat.css
```

`scripts/check-drift.mjs` holds tokens to the spec — it blocks publishing on mismatch.
`scripts/check-contrast.mjs` recomputes the figures §07 rests on.
`scripts/build-flat-css.mjs` emits the self-contained stylesheet Claude Design needs,
since rendered designs receive no Tailwind to resolve `@apply`.

**Never hand-edit `spec/`** — it is generated by Claude Design and re-exported here.
`guidelines/` is derived from the spec; [messaging and terminology](docs/messaging.md)
is maintained separately.
Everything else is ordinary source. See `CLAUDE.md`.

## Consumers

- `~/code/haikei/marketing-site` — the website.
- `~/code/haikei/kei` (`frontend/`) — the product UI.

When the spec changes, re-derive `guidelines/`, bump the package, and update both, or
they drift.

## Still open

- Confirm the mark. 3a, filled overlap, is specified as primary; the three alternates on
  the logo sheet are still live.
- A distinctive display face for headlines — the spec flags this as the one upgrade
  worth considering before anything prints.
- A dedicated dark value for `--color-accent-soft` (the light value is inherited today).
- Swag, LinkedIn, Substack and GitHub templates are specified by the rules but not built.
