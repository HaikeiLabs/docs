# Contrast

Measured, not estimated. `scripts/check-contrast.mjs` recomputes these on every
`npm test`, so the reasoning below cannot silently rot.

| Pairing | Ratio | WCAG AA (4.5:1) |
| --- | --- | --- |
| Emerald 700 `#047857` on ink `#07110d` | **3.50:1** | ✗ fails |
| Mint 300 `#6ee7b7` on ink `#07110d` | **12.58:1** | ✓ passes |
| Ink on canvas `#f6f8f6` | 17.97:1 | ✓ passes |
| Canvas on ink | 17.97:1 | ✓ passes |
| Amber 700 `#b45309` on white `#ffffff` | **5.02:1** | ✓ passes |
| Amber 700 `#b45309` on light risk bg (composited `#fffdf3`) | **4.93:1** | ✓ passes |

## What this justifies

The first row is the whole reason dark mode is not a simple inversion. Emerald 700
cannot carry text on ink — it fails AA for body copy. So §07 splits the accent role
in two:

- **`--color-accent-text`** — links, eyebrows, icons, anything a reader reads.
  Emerald 700 on light, **mint 300 on dark**.
- **`--color-accent`** — solid fills: buttons and the one full-bleed CTA band.
  **Emerald 700 in both themes**, because contrast there is against the fill's own
  foreground, not against the page ground.

A change that flips both tokens, or neither, breaks this. It is the single most
misunderstood rule in the system.

The amber rows justify the light risk tokens (HAI-1039): danger and destructive
states use amber, never red — and amber 700 ink clears AA on both a white surface
and the light risk card itself.

Check contrast when introducing any new pairing. Target AA (4.5:1) for body text.
