# §08 Screen density

Show the information an administrator needs for the current task. Keep identifiers,
implementation language, secondary actions, and keyboard help out of the default view.

## Rules

### 1. Show names, not IDs

Use a person's or connector's name in the main view. Put IDs in a details expander
when an administrator needs them for support or troubleshooting.

**Before** — the same connector UUID repeated across a policy card:

```text
Connector: 7f3a…9c21
Source: 7f3a…9c21
Target: 7f3a…9c21
```

**After** — show its name once and keep the identifier in details:

```text
Connector: Payroll
▸ Details
  Connector ID: 7f3a…9c21
```

### 2. Use product language in the default view

Keep internal implementation terms and formulas out of default views. Explain the
user outcome in plain language; put technical terms in details only when needed.

**Before**:

```text
Call-time (kei-proxy) · PDP check · connector_id: 7f3a…9c21
precedence = deny > allow, then priority desc
```

**After**:

```text
This request is checked against your policy before the connector runs.
▸ Technical details
  Enforcement point: kei-proxy
  Connector ID: 7f3a…9c21
```

### 3. Give each card one primary action

Keep one action visually primary on a card. Put secondary actions and supporting
details behind a click so the next step is clear.

**Before**:

```text
[Edit policy] [Copy ID] [View JSON] [Delete]
```

**After**:

```text
[Edit policy]  ···
               Copy ID
               View JSON
               Delete
```

### 4. Show keyboard hints on request

Keep shortcut help behind a visible `?` control. Do not reserve screen space for a
permanent shortcut bar.

**Before**:

```text
⌘K Search   G then P Policies   ? Shortcuts
```

**After**:

```text
? Help
```

Opening Help reveals the available shortcuts.
