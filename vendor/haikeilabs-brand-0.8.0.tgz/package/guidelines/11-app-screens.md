# §11 App screens

App screens are where people do something: Break My Guardrails (the Playground), the Kei console and the interactive parts of the docs. They use the same brand as the website, quieter, and every result leads somewhere.

These rules come from a review of playground.haikeilabs.com in November 2026. The website (§04), screen density (§08) and community links (§09) still apply.

## 1. One name per product, everywhere

- The game is **Break My Guardrails**. Use that name in the page title, the share card and the game's own header.
- **Playground** is only the link label that points to it, in the haikeilabs.com header, footer and docs. Don't call the game "the Playground" in its own copy.
- The company wordmark is **Haikei Labs** in Inter 600 at −0.03em (§01), drawn with the `Logo` component. Never set it in capitals ("HAIKEI LABS") or bold capitals.

## 2. Labels and case

- Headings, buttons in running text, links and menu items: sentence case.
- **Eyebrows** (one per section, such as "Objective" or "On-call · Level 1 of 5"): JetBrains Mono 500, uppercase, +0.18em (`.eyebrow`, §03). An eyebrow in mixed case is the same bug as a bold sans eyebrow.
- **Chips and data labels** (tool names, states, counts): JetBrains Mono 500, as the data is written (`k8s.delete_pod`, `allow`), +0.06em, never wider tracking.
- US spelling throughout: defense, color, behavior.

## 3. Plain states

Say what is true, not what isn't forbidden.

| Instead of | Write |
| --- | --- |
| not forbidden | Allowed |
| forbidden | Denied |
| Kei · open | No Kei policy |
| Kei · enforced | Kei policy on |
| pending | Checking |

Decision colors follow the README: allow is emerald (`kei-permit-*`), deny is amber (`kei-deny-*`), in both themes. Explain the decision in one plain sentence; put rule names and IDs behind "Technical details" (§08).

## 4. Hierarchy and emphasis

- Inter **400/500/600 only** (§03). Screen titles and card titles are 600; a light heading is drift.
- **One active element per screen.** Show it with a 1px `color-accent-text` border and the `color-accent-soft` fill. Focus rings are 2px with a 2px offset, and no glow. Neither may cover neighboring text.
- **The action goes above the fold.** On desktop, put the brief and the working area side by side. At 1,024px and below, show a one-line brief, then the working area, with the rest behind a disclosure.
- A brief is a goal, a task and a hint, each one sentence. The hint is set apart, in `color-muted`.

## 5. Every result leads somewhere

A win, a loss or a finished task ends on a result panel with:

1. What happened, in one sentence.
2. Which defense held or failed: the prompt, a guardrail or Kei policy.
3. The policy line that would stop it, as code.
4. **One primary action** to do the same with your own agent: the bring-your-agent quick start in the docs, carrying the source parameter.
5. A secondary action: the next level, or try again.

## 6. Voice and play

The Sage with the Creator (§00). Play is welcome when it teaches.

- Playful scenario names are fine: "Pinky Promise", "No Takesies Backsies".
- Every company in a scenario is fictional ("Kumquat Logistics"). Never a parody of a real company or product, and no jokes at anyone's expense.
- Say exactly what you collect. Model line: "We read only your public name. No email, no marketing."

## 7. Links, tracking and discovery

- Follow §09: Docs, GitHub and Discord in the header and footer. Add a visible way back to haikeilabs.com.
- Links from haikeilabs.com into an app carry `utm_source=haikeilabs&utm_medium=site&utm_content=<placement>`. Links from an app to app.haikeilabs.com carry the landing page and channel.
- Public screens meant to be found (each scenario) prerender their own title, description and share card. `robots.txt` and `sitemap.xml` are real files, not the app.

## 8. Contrast

Small mono labels sit near the AA floor. Use `color-muted` or `color-faint` on `color-surface`, never a lowered opacity, and check any new pairing at 4.5:1 (contrast).
