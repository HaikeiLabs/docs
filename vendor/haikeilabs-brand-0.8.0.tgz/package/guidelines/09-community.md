# §09 Community links

Every public Haikei surface connects people to the Docs, GitHub and Discord. Keep
these links visible so developers can find the community as the product grows.

## Rules

### 1. Link the three destinations on every public site

Link Docs (`https://docs.haikeilabs.com`), GitHub
(`https://github.com/HaikeiLabs`) and Discord (`https://discord.gg/g6QaTYWXDa`) on
haikeilabs.com, docs.haikeilabs.com and every future public site so visitors can
always find the same destinations.

### 2. Keep links in the header, mobile menu and footer

Show GitHub and Discord as icon links with aria-labels next to Docs in the header
and mobile menu, and list all three as text links in the footer so they stay
available at every screen size.

### 3. Call Discord the developer community

Use copy such as “Join the developer community on Discord” and “Build with us,”
not “support” or “chat”; keep one community section near the end of the home page.

### 4. Mark external links clearly

Open external links in a new tab with `rel="noopener noreferrer"`, and show the
external-arrow icon beside text links so people know they are leaving the site.

### 5. Keep Console links task-focused

Console (`app.haikeilabs.com`) is for admins: link Docs from help and setup, and
Discord from the help menu; do not add a community section.

### 6. Check links in every redesign review

Redesign PRs must keep these destinations; reviewers search for `discord.gg`,
`github.com/HaikeiLabs` and `docs.haikeilabs.com` so a site change cannot drop them
silently.
