# §02 Color

One green, one near-black, one warm-grey canvas.

**Emerald 700 `#047857` is the only brand color.** Everything else is structure. The
full scale exists so charts, states, and dark surfaces stay inside the family instead
of inventing new greens.

## Emerald scale

| Step | Hex | | Step | Hex |
| --- | --- | --- | --- | --- |
| 50 | `#ecfdf5` | | 500 | `#10b981` |
| 100 | `#d1fae5` | | 600 | `#059669` |
| 200 | `#a7f3d0` | | **700 ★** | **`#047857`** |
| 300 | `#6ee7b7` | | 800 | `#065f46` |
| 400 | `#34d399` | | 900 | `#064e3b` |
| | | | 950 | `#022c22` |

## Structure

| Name | Hex | Role |
| --- | --- | --- |
| Ink | `#07110d` | Body text, dark sections, logo tile |
| Canvas | `#f6f8f6` | Default page ground |
| Slate 600 | `#475569` | Secondary copy |
| Slate 200 | `#e2e8f0` | Hairlines, card borders |

## Roles — do not improvise

- **Emerald 700** — primary buttons, links, eyebrows, icons, the one full-bleed CTA
  band. **Never as a page background.**
- **Emerald 300** — accents on ink surfaces only (dark-section icons and eyebrows).
- **Emerald 50/100** — success states, quiet callout cards.
- **Ink** — one dark section per page or deck run; body copy at full strength.
- **Amber 300/700** (`#fde68a` / `#b45309`) — risk and warning cards. **The only
  non-green hue in the system.**

Because amber is the only sanctioned non-green hue, **danger and destructive states
use amber, never red** — green plus red reads as Christmas, and a red danger
treatment has no backing in this spec. The `--color-risk-*` tokens are amber in
both themes.
