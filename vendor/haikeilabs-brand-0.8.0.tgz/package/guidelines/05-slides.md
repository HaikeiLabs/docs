# §05 Slides

**1920 × 1080. Four layouts. Nothing below 24px.**

Margins **120px**, 12-column grid, **40px gutters**. Ink title slides bracket the
deck; canvas slides carry the argument; **one emerald slide per deck** for the ask.

## The four layouts

| Layout | Ground | Specifics |
| --- | --- | --- |
| **Title / section** | Ink | Title 120px, eyebrow mono 28px |
| **Content** | Canvas | Headline 84px, card body 28px |
| **Data** | White | Emerald 700 → 300 → slate 200. **Never more than three series** |
| **Statement** | Emerald | One per deck, centered, no body copy |

## Rules

- **Nothing below 24px.** A deck is read across a room.
- Pick **one theme per deck and stay there** (§07). Dark reads well in a room; light
  survives a bad projector and prints.
- A dark deck loses the light/dark contrast beat, since the ink title slide is
  unchanged — alternate `#0b1712` and `#0f1c17` grounds instead.
