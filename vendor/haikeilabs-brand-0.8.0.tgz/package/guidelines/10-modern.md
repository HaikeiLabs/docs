# §10 The Modern layer

An opt-in visual layer for launch pages, campaign surfaces, and developer-facing
hero moments. Hand-authored, approved with revision 4 of the Agentware onboarding
study; the normative copy is [§10 in spec/SPEC.md](../spec/SPEC.md), appended by
`npm run spec` from `spec/modern-section.md`. Like §08 and §09, preserve this file
when the specification is re-exported.

## Opting in

Put `data-style="modern"` on the root element or any wrapper:

```html
<html data-style="modern">            <!-- whole page -->
<div data-style="modern"> … </div>    <!-- one section inside a base page -->
```

The layer's tokens cascade to the subtree and its component classes apply only
inside it. With the attribute absent nothing applies. Import the layer's CSS and,
optionally, its behaviors:

```css
@import "@haikei/brand/index.css"; /* includes the layer; costs nothing until used */
/* or the part alone: */
@import "@haikei/brand/modern.css";
```

```html
<!-- copyable commands and the circle cursor; optional, progressive -->
<script src="@haikei/brand/modern.js" defer></script>
```

## What changes

Modern keeps the brand colors and fonts and is **dark-first by definition**: it
applies the §07 dark palette even inside a light page, so mint carries every
text, link, and icon role and emerald 700 keeps only its fills. The layer adds no
colors — its token block is a machine-checked mirror of the §07 dark block
(`scripts/check-drift.mjs` fails the build if the two diverge).

| Piece | Base system | Modern |
| --- | --- | --- |
| Display headline | §03 sizes | `clamp(2.75rem, 5.4cqi, 6rem)`, line-height .9, tracking −.065em; `10cqi` below 760px |
| Accent span | — | One per display: italic 500, tracking −.05em, mint (`--color-accent-text`) |
| Section headline | §03 sizes | `clamp(2rem, 5.2cqi, 4.25rem)`, line-height .98, tracking −.05em |
| Nav links | `.nav-link`, sans | `.modern-nav-link`: mono 500, 11px, +.08em, uppercase |
| Buttons | `.button-*`, 9999px pills | `.modern-button` + a `.button-*` variant: 8px corners, mono 500 12px, +.1em, uppercase (`.modern-button-sm` for small) |
| Eyebrow | `.eyebrow` | Gains a 28px leading rule; otherwise unchanged |

The italic is the one sanctioned departure from §03 (which admits no italic):
`assets/fonts.css` loads Inter italic 400/500 so the accent is real, not a faked
oblique. Nothing else in the system uses those faces.

## Components

**Stats row** — hairline-ruled numbers over mono uppercase labels:

```html
<div class="stats">
  <div><b>0.15.0</b><span>Agentware release</span></div>
  <div><b>3</b><span>SDK languages published</span></div>
</div>
```

Stats must be real — from the repos, the docs, or the live site. Never invented.

**Copyable command** — mono command in a recessed field; `data-modern-copy` opts
the button into the copy behavior from `scripts/modern.js`:

```html
<div class="cmd" data-modern-cmd>
  <span class="cmd-prompt" aria-hidden="true">$</span>
  <code>kei login && kei setup</code>
  <button type="button" data-modern-copy aria-label="Copy command">Copy</button>
</div>
```

Without the script the command stays selectable text and the button does nothing.

**Ticker** — marquee rows for lists longer than the viewport. The track carries
its content twice; the second copy is the loop echo and must be `aria-hidden`.
Log rows use the real decision pills (HP-C12):

```html
<div class="ticker" aria-label="Supported assistants">
  <div class="tk-row"><div class="tk-track">
    <span class="tk-item">Claude Code</span>
    <span class="tk-item">Codex</span>
    <span class="tk-item" aria-hidden="true">Claude Code</span>
    <span class="tk-item" aria-hidden="true">Codex</span>
  </div></div>
</div>
```

Add `.is-rev` to a `.tk-row` to run it backwards (60s instead of 48s). A demo
allow/deny log must be labeled as a demo — illustrative decisions are not a live
feed.

**Retro window** — mock-classic chrome for news panes and dialogs:

```html
<div class="w95">
  <div class="w95-bar"><span>Release</span><span class="w95-btns"><button aria-label="Dismiss">–</button><button aria-label="Close">×</button></span></div>
  <div class="w95-body"><p>Agentware 0.15.0 — Python manifest v3 …</p><button class="w95-ok">OK</button></div>
</div>
```

Decorative chrome — not a container for essential tasks.

## Accessibility

- **Circle cursor** — per the owner's 2026-11-15 decision, a plain 1.5px
  accent-text outline with no fill, glow, or halo. Fine pointers only (`pointer: fine`), grows over links and
  buttons, and is fully off under `prefers-reduced-motion: reduce`. The native
  cursor stays until `scripts/modern.js` is actually running (it adds
  `.has-modern-cursor`), so a failed script never leaves a cursorless page. The
  modern root must not carry a CSS transform, or the fixed ring positions
  relative to it instead of the viewport.
- **Pointer motion** — nearby hero dots may brighten within 100px and ease back
  over 500ms. Buttons may lift 2px on hover and scale to 97% on press with a
  200ms transform transition, only for fine pointers and when motion is enabled.
  Reduced motion disables both effects; keyboard focus keeps its normal ring.
  Blur and parallax remain banned.
- **Tickers** — pause on hover and on focus-within; under
  `prefers-reduced-motion: reduce` the animation stops and the echo copy is
  hidden, so the list reads as a wrapped static block.
- **Contrast** — the §07 discipline holds: mint on ink is 12.58:1, muted on ink
  8.60:1, faint on ink 6.32:1. Emerald 700 never carries text on the modern
  ground. `scripts/check-contrast.mjs` re-measures these.
- **No horizontal scroll at 375px** — the display sizes are fluid clamps, and the
  ticker and command overflow inside themselves, never the page.

## Do and don't

- **Do** use Modern for launch pages, announcements, and developer-facing hero
  moments; keep the rest of the site on the base system.
- **Don't** use the display scale for body copy — body stays §03 400/500.
- **Don't** put emerald 700 text on the modern ground — mint only (§07).
- **Don't** run a ticker as the only carrier of essential information.
- **Don't** extend the layer with new colors, a second shadow, or new radii — it
  changes type scale, tracking, and the listed components, nothing else.
