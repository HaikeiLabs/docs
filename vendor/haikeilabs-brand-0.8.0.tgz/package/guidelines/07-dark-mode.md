# §07 Dark mode

Same system, inverted — with two colors that swap roles.

Dark mode is **not a filter over the light theme**. Two things change deliberately:
**ink becomes the page ground**, and **emerald 700 stops carrying text** — mint 300
takes over every text, link, icon and eyebrow role, because emerald 700 on near-black
measures 3.50:1 and fails WCAG AA (see `contrast.md`). Emerald 700 keeps only its
solid-fill jobs: buttons and the one full-bleed CTA band.

## Tokens

| Token | Light | Dark | Role |
| --- | --- | --- | --- |
| `bg` | `#f6f8f6` | `#07110d` | Page ground |
| `surface` | `#ffffff` | `#0f1c17` | Cards, white sections |
| `field` | `#ffffff` | `#0b1712` | Inputs — recessed, darker than the card |
| `line` | `#e2e8f0` | `#fff` @ 10% | Hairlines, card borders |
| `text` / `text-2` | `#07110d` / `#475569` | `#f6f8f6` / `#a3b1aa` | Body and secondary copy |
| `accent-text` | `#047857` | `#6ee7b7` | Links, eyebrows, icons |
| `accent` (fill) | `#047857` | `#047857` | Buttons and the CTA band — **unchanged** |
| `tile` | `#07110d` | `#f6f8f6` | Logo tile and nav button invert |
| `risk` | `#fde68a` / `#b45309` | amber @ 12% / `#fcd34d` | Risk and warning cards |

The spec's dark table has **no row for emerald 50/100** (success states, quiet
callouts). `--color-accent-soft` therefore ships light-only; its dark value is an open
decision, not something to infer.

## Components on dark

**Secondary buttons lose their fill and become an outline** — a white card floating on
ink reads as a modal, not a button. Inputs sit recessed on `--color-field`, darker
than the card containing them.

## Where dark mode applies

- **Product UI and the website** — yes. Follow `prefers-color-scheme` with a manual
  override.
- **Slides** — pick one theme per deck and stay there.
- **Documents and print** — **light only. Never produce a dark PDF.**
- **Social and swag** — ink ground is the default already; treat it as the primary
  look, not a variant.

## Implementation

Theme resolves via `data-theme` on `<html>`. Inline `scripts/theme-init.js` in the
head **before any stylesheet** so a stored dark preference does not flash light; it
follows the OS until the visitor chooses, then persists to `localStorage` under
`haikei-theme`. `ThemeToggle` drives it.
