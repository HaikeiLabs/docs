# §01 Logo

Two planes overlap. The data lives in the overlap.

The back plane is the raw context — the *haikei*. The front plane is the policy
boundary. What is governed is what sits inside both: four data points knocked out of
a solid intersection, a foreground emerging from a structured background.

## The rule that governs every other logo decision

**The square behind the mark is always the page ground** — white in light mode, ink in
dark mode. Never a chip in the opposite color. The data points are knocked out *to
that ground*, which is why the mark never draws its own backdrop.

## Colorways

| Colorway | Back plane / overlap | Front plane | Points |
| --- | --- | --- | --- |
| Light (white ground) | Emerald 700 | Ink | Knocked out to white |
| Dark (ink ground) | Mint 300 | White | Knocked out to ink |
| On emerald 700 | White at 62% | White | Knocked out to emerald |
| One-color | Ink | Ink | For laser, etch, single-head embroidery, one-color print |

## Rules

- Clear space on all four sides ≈ **25% of mark height**.
- Minimum size **16px digital, 6mm printed**. Below 24px use the reduced mark.
- **Below 24px: one plane, one point.** Four dots close up and go to mud.
- Ground is white, ink, or emerald 700 — nothing else, and **never a photograph**.
- Wordmark is Inter Semibold, −0.03em tracking, "Haikei Labs" on one line, gap ≈ 35%
  of mark height.

## Never

- Put the mark in a contrasting square — no black chip on a white page, no white chip
  on ink.
- Rotate, skew, outline, or add a gradient or shadow to the mark.
- Recolor the planes to anything but emerald 700, mint 300, white, or ink.
- Stack the wordmark under the mark — horizontal only.

## In code

Render with the `Logo` component rather than an `<img>`: it follows the page theme
and switches to the reduced mark automatically below 24px.

```tsx
<Logo size={32} />              // follows the theme
<Logo size={32} tone="ink" />   // forced dark colorway, for a permanently dark ground
```

Stroke width is **2.1**. The Kei frontend's inlined copy used 2.2 — if you see that
value anywhere, it is drift.
