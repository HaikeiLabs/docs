# §06 Documents & print

Letter, one column, generous margins.

## Page

- **US Letter portrait.** Margins 25mm outer / 22mm top / 20mm bottom.
- **A4 must not reflow** — design to fit both.

## Type

- Body **12pt Inter 400 at 1.65 leading**, measure **68–72 characters**.
- **Never below 12pt**, footnotes at 10pt for exception-free legal copy only.
- H1 24pt / H2 18pt / H3 14pt, all Semibold at −0.02em.
- Eyebrow 9pt mono, +0.18em, emerald 700.

## Furniture

- Running header: horizontal lockup left, document type right in mono.
- Footer: domain and page number.
- Pull quotes get a 2px emerald 700 left rule — **the only decoration allowed in body
  text**.

## Print

- CMYK: emerald 700 ≈ **91/24/76/9**.
- On **uncoated stock use emerald 600** to compensate for dot gain.

## Light only

**Documents and print are light-only. Never send a dark PDF** — it burns toner and
photocopies as a black rectangle.
