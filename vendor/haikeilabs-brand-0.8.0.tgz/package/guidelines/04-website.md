# §04 Website

Rhythm, components, and the rules the site already follows.

## Structure

- Container **1280px**, gutters 32px (20px mobile). Header 80px tall, transparent over
  the hero.
- Section padding **128px** desktop / 96px tablet / 64px mobile.
- Editorial two-column split: 0.75fr / 1.25fr with an 80px gap. Card grids 2-up or
  3-up, 20px gap.
- Ground alternates canvas → white → canvas → ink → emerald → white. **At most one ink
  section and one emerald band per page.**
- Spacing scale: 4 · 8 · 12 · 16 · 20 · 24 · 28 · 32 · 40 · 64 · 80 · 128.

## Surfaces

- **Radii:** 8px logo tile · 12px inputs · 16/24px cards · 9999px buttons and pills.
- **One shadow only:** `0 1px 2px rgba(0,0,0,.05)`. No layered or colored shadows,
  no `shadow-xl`.
- Borders are 1px slate 200; on ink they are 1px white at 10%, fill white at 5%.
- Hero glow: emerald 500 at 16%, radial, 35% stop — **the only gradient in the system**.
- Icons: Lucide, 1.5–2px stroke, 24/28px, emerald 700 on light and emerald 300 on ink.

## Components

Provided by `@haikei/brand`: `Button` (primary / secondary / dark), `Card`, `Input`,
`Modal`, `Table` with `Pagination`, `Logo`, `ThemeToggle`.

Helper classes: `.eyebrow`, `.page-width`, `.nav-link`, `.button-primary`,
`.button-secondary`, `.button-dark`, `.field`, `.field-label`, `.answer-card`,
`.surface`, `.surface-raised`, `.hairline`, `.text-muted`, `.text-faint`,
`.risk-card`, `.risk-ink`.

Feature card: icon, 32px gap, title, 12px gap, body. 24px radius, 32px padding.

## Motion

Hand-authored from the DX study prototype, not yet in the `.dc.html` spec — preserve
this section when the specification is re-exported, as with §08–§10.

**Live background field.** Marketing-page heroes may carry the connected-dots field,
`mountHeroField(host)` from `@haikeilabs/brand/hero-field.js`.

- **One ripple** on load, and one per click or tap. Per the owner's 2026-11-15
  decision, dots within 100px of the pointer may brighten gently and ease back
  over 500ms. No hover trails, parallax, or **blur**.
- Under `prefers-reduced-motion` it is a **still field** — no ripples or pointer response.
- Buttons may lift 2px on hover and scale to 97% on press, using a 200ms
  transform transition. This is limited to fine pointers with motion enabled;
  keyboard focus retains its normal focus ring without a bounce.
- Colours come from `--hero-field-dot` and `--hero-field-accent` on the host (defaults:
  white at 16% and mint 300, for ink grounds). Set them from tokens; add no new hues.
- The host is `position: relative; overflow: hidden`, its content sits above the canvas
  (`z-index: 1`), and the canvas is `aria-hidden`. Call the returned `stop()` on unmount.

**How it works animation.** `KeiFlow(el, { static })` from
`@haikeilabs/brand/kei-flow.js`, styled by `@haikeilabs/brand/kei-flow.css`. It loops
for 9 seconds, so:

- Give it a **visible Pause control** next to the animation.
- Under `prefers-reduced-motion` render the **final frame, already paused**
  (`static: true`), with the control showing Play.
- It is dark by design and keeps its own §07 dark palette on any page ground.
