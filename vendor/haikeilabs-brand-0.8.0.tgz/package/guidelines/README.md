# Haikei Labs brand guidelines

Derived from `spec/Haikei Design Spec.dc.html` (v0.2, September 2026), which is the
source of truth. **These files are derived, not authored** — when the spec is
re-exported, re-derive them or they become a second stale copy, which is the exact
failure this repo exists to end.

| File | Spec section |
| --- | --- |
| `00-brand.md` | Brand identity — name, tagline, archetype, tone |
| `01-logo.md` | §01 Logo |
| `02-color.md` | §02 Color |
| `03-typography.md` | §03 Typography |
| `04-website.md` | §04 Website |
| `05-slides.md` | §05 Slides |
| `06-documents-print.md` | §06 Documents & print |
| `07-dark-mode.md` | §07 Dark mode |
| `08-screen-density.md` | Console screen density |
| `09-community.md` | Community links (hand-authored guideline) |
| `10-modern.md` | §10 The Modern layer (hand-authored guideline) |
| `11-app-screens.md` | §11 App screens (hand-authored guideline) |
| `contrast.md` | Measured contrast figures and what they justify |
| `SPEC.md` | **The complete specification as plain text**, all seven sections plus the hand-authored §10 Modern layer |
| `asset-index.md` | Every exported asset and when to use it |

## The five rules most often broken

1. **Never hardcode a color.** Everything goes through a token. A raw hex or a
   framework color utility will not survive dark mode.
2. **Accent text and accent fill are different tokens.** On dark, text flips to mint
   300; fills stay emerald 700. Swapping both, or neither, is wrong.
3. **Eyebrows are JetBrains Mono 500 at +0.18em.** A bold uppercase sans looks close
   and violates §03.
4. **One shadow only:** `0 1px 2px rgba(0,0,0,.05)`.
5. **The square behind the logo is the page ground**, never a contrasting chip.

For console screens, follow [§08 Screen density](08-screen-density.md): show names,
keep internal terms and secondary details out of the default view, and expose
keyboard hints only on request.

[§09 Community links](09-community.md) is a hand-authored exception to the derived
guidelines above. Preserve it when the specification is re-exported.

[§10 The Modern layer](10-modern.md) is likewise hand-authored (approved with
revision 4 of the Agentware onboarding study): an opt-in `data-style="modern"`
layer for launch and campaign surfaces. Its normative copy is appended to
[spec/SPEC.md](../spec/SPEC.md) by `npm run spec` from `spec/modern-section.md`.
Preserve both when the specification is re-exported.

[§11 App screens](11-app-screens.md) is likewise hand-authored: the rules for
product screens such as Break My Guardrails (the Playground), from a November 2026
review of playground.haikeilabs.com. Preserve it when the specification is
re-exported. Its section is not yet appended to `spec/SPEC.md` — that needs the
same script change as the §10 pattern.
