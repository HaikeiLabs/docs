# §03 Typography

Inter for everything, mono for labels.

Weights **400/500/600 only** — no light, no black. Headlines get negative tracking;
small uppercase labels get +0.18em. JetBrains Mono is reserved for eyebrows, data
labels, code, and version stamps: it is what makes the brand read technical without a
second display face.

## Scale

| Role | Size | Weight | Tracking | Leading |
| --- | --- | --- | --- | --- |
| Display | 92px | 600 | −0.055em | |
| H2 | 48px | 600 | −0.025em | |
| H3 | 24px | 600 | | |
| Lead | 20px | 400 | | 32px |
| Body | 16px | 400 | | 28px |
| Eyebrow | 12px | mono 500 | +0.18em | |

Body copy never runs wider than **72 characters**.

## Eyebrows

The most-repeated bug in this system is a hand-rolled eyebrow. Writing
`text-xs font-bold uppercase tracking-[0.18em]` produces a **bold sans** eyebrow that
looks close and violates this section — eyebrows are **mono 500**.

Use the `.eyebrow` class.

## Loading

Inter 400/500/600 and JetBrains Mono 500, via `@haikei/brand/fonts.css`. Add the
preconnect pair to the document head as well; a CSS `@import` cannot express it.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
```
