# Asset index

Every exported brand asset and when to use it. Prefer the SVG; PNGs exist for
contexts that cannot take vector.

## Marks and lockups

| File | Use |
| --- | --- |
| `haikei-mark-on-light.*` | **Default.** Emerald 700 back plane and overlap, ink front, points knocked out to white. |
| `haikei-mark-on-ink.*` | Mint 300 back plane and overlap, white front, points knocked out to ink. |
| `haikei-mark-on-emerald.*` | All white, back plane at 62%. CTA bands and stickers only. |
| `haikei-mark-one-color.*` | Single ink. Laser, etch, single-head embroidery, one-color print. |
| `haikei-mark-reduced-on-light.*` | Reduced mark for below 24px: one plane, one point. |
| `haikei-mark-reduced-on-ink.*` | Reduced mark, dark ground. |
| `haikei-lockup-on-light.*` | Horizontal lockup with wordmark, light grounds. |
| `haikei-lockup-on-ink.*` | Horizontal lockup with wordmark, dark grounds. |

## Favicons

`assets/favicon/`. The `.svg` carries both themes via `prefers-color-scheme`; the
raster fallbacks use the reduced mark at and below 32px.

## Coding harnesses

`assets/harnesses/` contains monochrome SVG compatibility marks for Claude Code,
Codex, Cursor, OpenCode, Pi and Discord. Their `currentColor` fill adapts to light and dark
themes through the consumer's CSS; prefer SVG and set `color` to an accessible
foreground. These third-party marks are nominative compatibility indicators. See
[`assets/harnesses/ATTRIBUTION.md`](../assets/harnesses/ATTRIBUTION.md) for sources and
usage terms.

## Partner badges

`assets/partners/` holds the NVIDIA Inception Program member badges, byte-identical
copies of NVIDIA's "for screen" pack. They indicate program membership only. See
[`assets/partners/ATTRIBUTION.md`](../assets/partners/ATTRIBUTION.md) for sources and
the full rules.

| File | Use |
| --- | --- |
| `nvidia-inception-program-badge-rgb-for-screen.svg` | **Default**, on light and dark pages alike. Its own white panel and black frame make it legible on any ground. |
| `nvidia-inception-program-badge-rgb-for-screen.png` | The same, where SVG is not accepted (email, some social and slide tools). 501 × 217. |
| `nvidia-inception-program-badge-rgb-1c-blk-for-screen.svg` | One-colour black, **only** where full colour cannot be reproduced (one-colour print, etch, fax-grade documents). |
| `nvidia-inception-program-badge-rgb-1c-blk-for-screen.png` | Raster of the one-colour badge. |

Rules:

- Use the full-colour badge in dark mode too. There is no reversed or dark version;
  do not make one, and do not invert the one-colour file.
- Never change its colours (`#76b900`, black, white), proportions or text, and never
  recolour it to a Haikei token. Render it with `<img>`, not inline with
  `currentColor`.
- Never write the program name in all caps: "NVIDIA Inception Program".
- The badge is never bigger than the Haikei logo beside it.
- Minimum 120px wide on screen. Keep clear space of at least the badge's own frame
  margin (about 5% of its width) on every side; never crop the file's built-in margin.
- Put the legal line next to it, in sentence case: "© 2026 NVIDIA and the NVIDIA logo
  are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and
  other countries."
- `#76b900` is NVIDIA's colour, not a Haikei token. It appears only inside these files.

```tsx
import nvidiaInception from '@haikeilabs/brand/assets/partners/nvidia-inception-program-badge-rgb-for-screen.svg'

<img src={nvidiaInception} alt="NVIDIA Inception Program member" width="160" height="69" />
```

## Social previews

`assets/social/share-card-dark-1200x627.png` is the default marketing and docs share card.
The `assets/social/repo-*-1280x640.png` files are GitHub social previews for their named repositories.
Render all cards from `assets/social/card-template.svg` with `python3 scripts/render-social.py` (requires Pillow).

## Full inventory

```
assets/logo/haikei-lockup-on-ink-1480.png
assets/logo/haikei-lockup-on-ink-370.png
assets/logo/haikei-lockup-on-ink-740.png
assets/logo/haikei-lockup-on-ink.svg
assets/logo/haikei-lockup-on-light-1480.png
assets/logo/haikei-lockup-on-light-370.png
assets/logo/haikei-lockup-on-light-740.png
assets/logo/haikei-lockup-on-light.svg
assets/logo/haikei-mark-on-emerald-1024.png
assets/logo/haikei-mark-on-emerald-128.png
assets/logo/haikei-mark-on-emerald-24.png
assets/logo/haikei-mark-on-emerald-256.png
assets/logo/haikei-mark-on-emerald-32.png
assets/logo/haikei-mark-on-emerald-512.png
assets/logo/haikei-mark-on-emerald-64.png
assets/logo/haikei-mark-on-emerald.svg
assets/logo/haikei-mark-on-ink-1024.png
assets/logo/haikei-mark-on-ink-128.png
assets/logo/haikei-mark-on-ink-16.png
assets/logo/haikei-mark-on-ink-24.png
assets/logo/haikei-mark-on-ink-256.png
assets/logo/haikei-mark-on-ink-32.png
assets/logo/haikei-mark-on-ink-512.png
assets/logo/haikei-mark-on-ink-64.png
assets/logo/haikei-mark-on-ink.svg
assets/logo/haikei-mark-on-light-1024.png
assets/logo/haikei-mark-on-light-128.png
assets/logo/haikei-mark-on-light-16.png
assets/logo/haikei-mark-on-light-24.png
assets/logo/haikei-mark-on-light-256.png
assets/logo/haikei-mark-on-light-32.png
assets/logo/haikei-mark-on-light-512.png
assets/logo/haikei-mark-on-light-64.png
assets/logo/haikei-mark-on-light.svg
assets/logo/haikei-mark-one-color-1024.png
assets/logo/haikei-mark-one-color-128.png
assets/logo/haikei-mark-one-color-24.png
assets/logo/haikei-mark-one-color-256.png
assets/logo/haikei-mark-one-color-32.png
assets/logo/haikei-mark-one-color-512.png
assets/logo/haikei-mark-one-color-64.png
assets/logo/haikei-mark-one-color.svg
assets/logo/haikei-mark-reduced-on-ink-16.png
assets/logo/haikei-mark-reduced-on-ink-32.png
assets/logo/haikei-mark-reduced-on-ink.svg
assets/logo/haikei-mark-reduced-on-light-16.png
assets/logo/haikei-mark-reduced-on-light-32.png
assets/logo/haikei-mark-reduced-on-light.svg
…
assets/favicon/favicon-16.png
assets/favicon/favicon-180.png
assets/favicon/favicon-192.png
assets/favicon/favicon-32.png
assets/favicon/favicon-48.png
assets/favicon/favicon-512.png
assets/favicon/favicon.ico
assets/favicon/favicon.svg
assets/harnesses/anthropic.svg
assets/harnesses/cursor.svg
assets/harnesses/discord.svg
assets/harnesses/openai.svg
assets/harnesses/opencode.svg
assets/harnesses/pi.svg
assets/harnesses/ATTRIBUTION.md
assets/partners/nvidia-inception-program-badge-rgb-1c-blk-for-screen.png
assets/partners/nvidia-inception-program-badge-rgb-1c-blk-for-screen.svg
assets/partners/nvidia-inception-program-badge-rgb-for-screen.png
assets/partners/nvidia-inception-program-badge-rgb-for-screen.svg
assets/partners/ATTRIBUTION.md
assets/social/card-template.svg
assets/social/share-card-dark-1200x627.png
assets/social/repo-agentware-1280x640.png
assets/social/repo-skills-1280x640.png
assets/social/repo-docs-1280x640.png
assets/social/repo-kei-cli-1280x640.png
assets/social/repo-kei-agents-1280x640.png
assets/social/repo-kei-connector-contracts-1280x640.png
assets/social/repo-github-workflows-1280x640.png
```

48 logo files, 8 favicons, 5 harness marks and their attribution, 4 partner badges and
their attribution.

## Rules

- Prefer the SVG everywhere it is accepted.
- In app code, render the mark with the `Logo` component rather than an `<img>` — it
  follows the theme and handles the sub-24px reduction.
- **If the mark changes, regenerate every variant, size and favicon** — not just the
  ones someone noticed.

`spec/screenshots/` holds the original Claude Design selection exports. They are
historical records of the mark decision, not production assets. Note that
`logo-selection-app-icon.png` places the mark on an ink tile: legitimate for an app
icon, where a tile is the platform's requirement, but **not** a licence for the
"contrasting chip" §01 forbids.
