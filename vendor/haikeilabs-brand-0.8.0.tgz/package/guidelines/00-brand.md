# Brand identity

| | |
| --- | --- |
| **Name** | Haikei — pronounced **Hi-kay** |
| **Tagline** | "The Background for Intelligent Action." |
| **Archetype** | The Sage with the Creator — precise · foundational · builders enabling builders |
| **Audience** | Builders first, then security and platform leads, then investors |
| **Tone** | Serious about claims, never breathless. Small, earned moments of play are fine. |

Haikei (背景) means *background*. Everything in this system serves one idea: Haikei is the
sovereign context framework, the background context that lets agents act while teams
keep their own models and their own data. Quiet surfaces, one confident
green, no decoration that isn't carrying meaning.

## The visual principle

Minimalist: **a foreground shape — the agent — emerging from a rich, structured
background of connected points.** The mark is the smallest statement of that idea; at
large sizes it extends into a background field of connections.

**The Sage does not decorate.** The pattern stays subordinate to the foreground, never
texture for its own sake. This is the constraint that separates the background field
from ornament — if the connections start competing with the content, they are wrong.

Practically, for anything you design:

- The connection field is a **large-format device only** — a hero, a title slide, a
  social cover. Never behind body copy, never behind a card, never at small sizes.
- It sits **behind and beneath**: low contrast, well under the foreground it supports.
  Emerald at low opacity on canvas, or mint at low opacity on ink.
- The mark itself is the compact form of the same idea. At normal sizes it does the
  whole job — do not add a field around it.
- **Never a photograph** behind the mark (§01), and the field is not an exception.

## How the tone reads

The Sage and the Creator govern copy as much as visuals. The Sage keeps claims
precise and load-bearing: "evaluate tool calls through policy the model cannot rewrite,"
not "revolutionize your AI security." No exclamation marks, no urgency theatre, no
hedged marketing verbs. The spec's own §05 slide titles are the register to match —
"The gap," "Where enforcement belongs," "Help shape the sovereign context layer."

The Creator is why we write as builders enabling builders: show the real command, the
real policy, the real tool call, and let people make something with it. Context has three
parts, named the same way everywhere: **Lexicon** (data), **Semantics** (meaning and
relationships) and **Pragmatics** (action).
