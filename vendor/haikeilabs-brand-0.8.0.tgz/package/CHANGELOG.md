# Changelog

## 0.8.0

- Remove the cursor ring's fill and add a restrained button hover and press bounce for fine pointers when motion is enabled.
- Hero dots briefly brighten near the pointer, with animation paused off-screen and in hidden tabs. Reduced motion keeps the field still.
- Mark `scripts/modern.js` as side-effectful so bundlers retain its cursor and copy-command initialization.
- Record the owner's 2026-11-15 motion decision in the guidelines and Modern specification.

## 0.7.3

- Tooltip help triggers use the themed accent text colour for readable contrast in dark mode (HAI-1062).

## 0.7.2

- Button labels are centred, so full-width buttons no longer left-align their text.

## 0.7.1

- `Modal` now closes on a click on its backdrop straight away. Kobalte arms its outside-pointerdown listener on a `setTimeout(0)` after the dialog mounts, so when the main thread was busy right after opening, a quick backdrop click landed before that timer and was dropped, leaving the dialog open (HAI-1040). The overlay now has its own click handler, live from mount; a click that only bubbles up from inside the dialog does not close it, and a dialog Kobalte already closed is not closed twice. The overlay also carries `data-kei-modal-overlay`. Markup, classes and props are otherwise unchanged.
- `npm test` now checks that the overlay is wired to the dismiss handler and runs that handler from the build with node's timers frozen: a backdrop click closes the dialog before any timer runs, and a click from inside does not.

## 0.7.0

- The light `--color-risk-*` tokens are now amber, matching the dark theme and §02, which sanctions amber as the only non-green hue: ink `#b45309`, line `#fde68a`, bg `rgba(255,251,235,.6)`. Danger and destructive states use amber, never red — green plus red reads as Christmas, and the previous red-tinted light values had no backing in the spec (HAI-1039).
- `npm test` now asserts the light risk ink is amber 700 and that no light risk token carries a red value, and the contrast check covers the new light pairs: amber ink on white (5.02:1) and on the light risk card (4.93:1), both passing AA.

## 0.6.0

- Add the NVIDIA Inception Program member badges under `assets/partners/`: full colour and one-colour black, SVG and PNG, byte-identical to NVIDIA's "for screen" pack. Import them from `@haikeilabs/brand/assets/partners/…`. `assets/partners/ATTRIBUTION.md` and the new "Partner badges" section of `guidelines/asset-index.md` carry NVIDIA's rules: full colour on light and dark, one colour only when full colour cannot be reproduced, no colour, proportion or text changes, never bigger than the Haikei logo, 120px minimum width, and the legal line beside it. `#76b900` is a third-party colour inside these files, not a token.
- `npm test` now checks that the packed tarball includes the partner badges and their attribution.

## 0.5.0

- Add the connected-dots hero field, `mountHeroField`, and the How it works animation, `KeiFlow` with `kei-flow.css`. Both are exported from the package entry and from the framework-free subpaths `@haikeilabs/brand/hero-field.js` and `@haikeilabs/brand/kei-flow.js`. Behaviour is unchanged from the prototype. `KeiFlow` is now an ES module export rather than a `window.KeiFlow` global, and its faint caption colour is §07 `#8b978f` rather than the off-spec `#7f918a`.
- Add §04 motion rules: one ripple, no cursor effects or blur, a still field under reduced motion, and a visible Pause control for the flow animation.

## 0.4.0

- Distribute consumer installs as vendored tarballs, with a script for upgrades and rollbacks.
- Add Select, Toggle and Tooltip, and generic card and modal affordances from the console.
