// Render the spec to plain markdown.
//
// The .dc.html spec is the source of truth, but it only reads properly in a browser
// with the Claude Design runtime. This writes spec/SPEC.md so the text is greppable
// and readable without a server — for agents, for grep, and for anyone who just wants
// to check a value.
//
// Regenerate after every re-export: `npm run spec`. The drift check verifies SPEC.md
// matches the .dc.html, so a stale copy fails the build rather than misleading someone.

import { readFileSync, writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const SRC = 'spec/Haikei Design Spec.dc.html'
const OUT = 'spec/SPEC.md'

const entities = { amp: '&', lt: '<', gt: '>', quot: '"', '#39': "'", nbsp: ' ', '#x27': "'" }
const unescape = (s) =>
  s.replace(/&(#x?[0-9a-fA-F]+|[a-z]+);/g, (m, e) => {
    if (entities[e]) return entities[e]
    if (e.startsWith('#x')) return String.fromCodePoint(parseInt(e.slice(2), 16))
    if (e.startsWith('#')) return String.fromCodePoint(parseInt(e.slice(1), 10))
    return m
  })

export function specToLines(html) {
  const stripped = html
    .replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/gi, '')
    .replace(/<[^>]+>/g, '\n')
  return unescape(stripped)
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean)
}

// Importable as a library (the drift check reuses specToLines above). Only writes when
// run directly, so importing it never has a side effect.
if (process.argv[1] === fileURLToPath(import.meta.url)) main()

function main() {
  const lines = specToLines(readFileSync(join(root, SRC), 'utf8'))
  const version = lines.find((l) => /v0\.\d+/.test(l))?.match(/v0\.\d+/)?.[0] ?? 'unknown'
  const header = `# Haikei Labs — brand & design specification

  **Plain-text rendering of \`${SRC}\`, ${version}.**

  This file is *generated* — \`scripts/extract-spec.mjs\` writes it from the \`.dc.html\`
  source. Never edit it by hand, and never treat it as the source of truth: the
  \`.dc.html\` renders real components, so its inline styles *are* the specification and
  this text cannot carry them. It exists so the spec is greppable and readable without
  a local server.

  To read the real thing:

  \`\`\`bash
  cd spec && python3 -m http.server 8000   # then http://localhost:8000
  \`\`\`

  ---
  `

  const isSection = (l) => /^\d{2} · /.test(l)
  const body = lines.map((l) => (isSection(l) ? `\n## ${l}\n` : l)).join('\n')

  // The hand-authored Modern layer section (§10) is not in the .dc.html; it is
  // appended from its own file and drift-checked by check-drift.mjs.
  const modernSection = readFileSync(join(root, 'spec/modern-section.md'), 'utf8')

  writeFileSync(join(root, OUT), `${header}\n${body}\n${modernSection.trim()}\n`)
  console.log(`✓ ${OUT} — ${lines.length} spec lines + §10 modern layer, spec ${version}`)
}
