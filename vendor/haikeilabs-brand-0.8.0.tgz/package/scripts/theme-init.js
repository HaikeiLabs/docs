// Resolve the theme before first paint so a stored dark preference does not
// flash the light ground. Inline this in the document <head>, before any
// stylesheet — as a file it would load too late to beat the first paint.
// Mirrors initialTheme() in src/components/ThemeToggle.tsx.
(function () {
  try {
    var stored = localStorage.getItem('haikei-theme')
    if (stored !== 'dark' && stored !== 'light') {
      stored = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
    }
    document.documentElement.dataset.theme = stored
  } catch (e) {
    document.documentElement.dataset.theme = 'light'
  }
})()
