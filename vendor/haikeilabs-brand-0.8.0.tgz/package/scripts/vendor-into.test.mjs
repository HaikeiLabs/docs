import { test } from 'node:test'
import { strict as assert } from 'node:assert'
import { mkdtemp, mkdir, writeFile, readFile, readdir, rm, chmod } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { spawnSync } from 'node:child_process'

test('vendors the working tree and replaces older archives without installing', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'brand-consumer-'))
  try {
    await mkdir(join(dir, 'vendor'))
    await writeFile(join(dir, 'vendor/haikeilabs-brand-0.1.0.tgz'), 'old')
    await writeFile(join(dir, 'package.json'), JSON.stringify({ name: 'consumer', dependencies: { other: '1.0.0' } }))
    const result = spawnSync(process.execPath, [resolve('scripts/vendor-into.mjs'), dir], { encoding: 'utf8' })
    assert.equal(result.status, 0, result.stderr)
    const manifest = JSON.parse(await readFile(join(dir, 'package.json')))
    const version = JSON.parse(await readFile('package.json')).version
    assert.equal(manifest.dependencies['@haikeilabs/brand'], `file:vendor/haikeilabs-brand-${version}.tgz`)
    assert.deepEqual(await readdir(join(dir, 'vendor')), [`haikeilabs-brand-${version}.tgz`])
    assert.match(result.stdout, /npm install/)
    assert.ok(!(await readdir(dir)).includes('node_modules'))
  } finally { await rm(dir, { recursive: true, force: true }) }
})

test('vendors the specified committed revision instead of the working tree', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'brand-ref-consumer-'))
  try {
    await writeFile(join(dir, 'package.json'), '{}')
    const bin = join(dir, 'bin')
    await mkdir(bin)
    const fakeNpm = join(bin, 'npm')
    await writeFile(fakeNpm, `#!/usr/bin/env node
const fs = require('fs'); const path = require('path');
if (process.argv[2] === 'pack') { const version = JSON.parse(fs.readFileSync('package.json')).version; fs.writeFileSync(path.join(process.argv[4], 'haikeilabs-brand-' + version + '.tgz'), version); }
`)
    await chmod(fakeNpm, 0o755)
    const result = spawnSync(process.execPath, [resolve('scripts/vendor-into.mjs'), dir, '--ref', 'HEAD'], { encoding: 'utf8', env: { ...process.env, PATH: `${bin}:${process.env.PATH}` } })
    assert.equal(result.status, 0, result.stderr)
    const committed = JSON.parse(spawnSync('git', ['show', 'HEAD:package.json'], { encoding: 'utf8' }).stdout)
    const manifest = JSON.parse(await readFile(join(dir, 'package.json')))
    assert.equal(manifest.dependencies['@haikeilabs/brand'], `file:vendor/haikeilabs-brand-${committed.version}.tgz`)
  } finally { await rm(dir, { recursive: true, force: true }) }
})
