// Drift check — herdr's ruleset as a machine check.
//
// The spec (spec/Haikei Design Spec.dc.html) is the source of truth. This asserts
// that the package has not drifted from it. Runs on `npm test` and blocks publish
// via prepublishOnly, so a token cannot diverge from the spec silently.

import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const read = (p) => readFileSync(join(root, p), 'utf8')

const failures = []
const fail = (rule, detail) => failures.push({ rule, detail })

const spec = read('spec/Haikei Design Spec.dc.html')
const tokens = read('src/tokens.css')
const pkg = JSON.parse(read('package.json'))

// 1. Every hex in tokens.css appears in the spec.
//
// Only the stylesheets are scanned, never assets/. assets/partners/ in particular holds
// NVIDIA's unmodified badge files, whose NVIDIA Green #76b900 is a third-party colour
// inside the artwork, not a Haikei token — do not add assets/partners/ to any hex scan.
//
// Hexes that are legitimately absent from the spec's own prose, with a reason.
const allowed = new Map([
  ['#a3b1aa', '§07 dark table: secondary copy on dark'],
  ['#8b978f', 'tertiary copy on dark, derived from the §07 muted ramp'],
  ['#0b1712', '§07 dark table: field, recessed below the card'],
  ['#0f1c17', '§07 dark table: surface'],
  ['#16241e', 'surface-hover on dark, one step above surface'],
  ['#f8fafc', 'surface-hover on light, one step below white'],
  ['#fcd34d', '§07 dark table: risk ink'],
  ['#fffbeb', 'HP-C12 access views: approved amber deny surface'],
  ['#cbd5e1', '§02 slate 300: input borders'],
  ['#065f46', '§02 emerald 800: accent hover'],
  ['#ffffff', 'white — structural, not a brand color'],
])

const specHexes = new Set((spec.match(/#?\b[0-9a-fA-F]{6}\b/g) ?? []).map((h) => `#${h.replace('#', '')}`.toLowerCase()))
const tokenHexes = [...new Set((tokens.match(/#[0-9a-fA-F]{6}\b/g) ?? []).map((h) => h.toLowerCase()))]

for (const hex of tokenHexes) {
  if (!specHexes.has(hex) && !allowed.has(hex)) {
    fail('hex-not-in-spec', `${hex} is in tokens.css but not in the spec, and is not an allowed derivation`)
  }
}

// 1b. The Modern layer (§10) adds no colors of its own — it mirrors the §07
//     dark column and reuses tokens, so any new hex there is drift.
const modernCss = read('src/modern.css')
const modernHexes = [...new Set((modernCss.match(/#[0-9a-fA-F]{6}\b/g) ?? []).map((h) => h.toLowerCase()))]
for (const hex of modernHexes) {
  if (!specHexes.has(hex) && !allowed.has(hex)) {
    fail('hex-not-in-spec', `${hex} is in src/modern.css but not in the spec — the Modern layer adds no colors`)
  }
}

// 1c. The How it works animation (§04) is dark by design and hard-codes the §07
//     dark palette — so every hex it uses must be one the spec or tokens sanction.
const keiFlowCss = read('src/kei-flow.css')
for (const hex of new Set((keiFlowCss.match(/#[0-9a-fA-F]{6}\b/g) ?? []).map((h) => h.toLowerCase()))) {
  if (!specHexes.has(hex) && !allowed.has(hex)) {
    fail('hex-not-in-spec', `${hex} is in src/kei-flow.css but not in the spec — the flow animation adds no colors`)
  }
}

// 2. The §07 accent split must hold: accent-text flips on dark, accent fill does not.
const darkBlock = tokens.match(/\[data-theme="dark"\]\s*{([\s\S]*?)\n}/)?.[1] ?? ''
if (!/--color-accent-text:\s*#6ee7b7/.test(darkBlock)) {
  fail('accent-split', 'dark --color-accent-text must be mint #6ee7b7 (§07: emerald 700 on ink is 3.50:1 and fails AA)')
}
if (!/--color-accent:\s*#047857/.test(darkBlock)) {
  fail('accent-split', 'dark --color-accent must stay emerald #047857 — fills keep emerald 700 (§07)')
}

// 2b. The light risk tokens are amber, never red (HAI-1039). §02 sanctions amber
//     as the only non-green hue; a red risk token would read as a second brand
//     color (green + red) and has no backing in the spec.
const lightRisk = Object.fromEntries(
  [...(tokens.match(/@theme\s*{([\s\S]*?)\n}/)?.[1] ?? '').matchAll(/(--color-risk-[\w-]+):\s*([^;]+);/g)].map(([, k, v]) => [k, v.trim()])
)
if (lightRisk['--color-risk-ink'] !== '#b45309') {
  fail('risk-amber', `light --color-risk-ink must be amber 700 #b45309, got "${lightRisk['--color-risk-ink'] ?? '(missing)'}" — danger/risk is amber, never red`)
}
for (const red of ['#b91c1c', '#dc2626', '#ef4444', '#fee2e2', '#fef2f2']) {
  if (Object.values(lightRisk).some((v) => v.toLowerCase().includes(red))) {
    fail('risk-amber', `a light risk token still carries red ${red} — danger/risk is amber, never red (HAI-1039)`)
  }
}

// 3. tokens.json agrees with tokens.css — it is generated, so a hand-edit to
//    either alone silently ships two different palettes.
const parseBlock = (pattern) => {
  const m = tokens.match(pattern)
  return m ? Object.fromEntries([...m[1].matchAll(/(--[\w-]+):\s*([^;]+);/g)].map(([, k, v]) => [k, v.trim()])) : {}
}
const cssTokens = { light: parseBlock(/@theme\s*{([\s\S]*?)\n}/), dark: parseBlock(/\[data-theme="dark"\]\s*{([\s\S]*?)\n}/) }
const jsonTokens = JSON.parse(read('src/tokens.json'))

for (const theme of ['light', 'dark']) {
  const css = cssTokens[theme]
  const json = jsonTokens[theme] ?? {}
  for (const [k, v] of Object.entries(css)) {
    if (json[k] !== v) fail('tokens-json', `${theme}.${k}: css has "${v}", tokens.json has "${json[k] ?? '(missing)'}"`)
  }
  for (const k of Object.keys(json)) {
    if (!(k in css)) fail('tokens-json', `${theme}.${k} is in tokens.json but not tokens.css`)
  }
}

// 4. One shadow only (§04). No layered or colored shadows anywhere in src/.
for (const file of ['src/tokens.css', 'src/base.css', 'src/components.css', 'src/modern.css', 'src/kei-flow.css']) {
  const css = read(file)
  for (const m of css.match(/shadow-(xl|2xl|lg|md)\b/g) ?? []) {
    fail('shadow', `${file} uses ${m}; §04 allows one shadow only: 0 1px 2px rgba(0,0,0,.05)`)
  }
}

// 5. The spec version stamp matches package.json.
const stamped = spec.match(/v0\.\d+/)?.[0]
if (stamped !== pkg.brandSpecVersion) {
  fail('version', `spec stamps ${stamped}, package.json brandSpecVersion is ${pkg.brandSpecVersion}`)
}

// 6. SPEC.md is generated from the .dc.html — a stale copy misleads anyone who
//    greps it instead of opening the spec.
const { specToLines } = await import('./extract-spec.mjs')
try {
  const expected = specToLines(spec)
  const actual = read('spec/SPEC.md')
  const missing = expected.filter((l) => !actual.includes(l))
  if (missing.length) {
    fail('spec-md', `spec/SPEC.md is stale — ${missing.length} spec line(s) absent, e.g. "${missing[0].slice(0, 60)}". Run: npm run spec`)
  }
} catch (e) {
  if (e.code === 'ENOENT') fail('spec-md', 'spec/SPEC.md is missing. Run: npm run spec')
  else throw e
}

// 7. The runtime must sit beside the .dc.html files or they render blank —
//    the exact failure that made marketing-site's vendored copy dead.
for (const f of ['spec/doc-page.js', 'spec/support.js']) {
  try {
    read(f)
  } catch {
    fail('runtime', `${f} is missing; the .dc.html files cannot render without it`)
  }
}

// 8. The Modern layer's [data-style="modern"] token block is a hand-maintained
//    mirror of the tokens.css dark block (Modern is dark-first by definition,
//    §10). A copy that silently diverges would ship two §07 palettes.
const modernBlock = modernCss.match(/\[data-style="modern"\]\s*{([\s\S]*?)\n}/)?.[1] ?? ''
const toDecls = (block) =>
  Object.fromEntries([...(block.matchAll(/(--[\w-]+):\s*([^;]+);/g))].map(([, k, v]) => [k, v.trim()]))
const darkDecls = toDecls(darkBlock)
const modernDecls = toDecls(modernBlock)
for (const [k, v] of Object.entries(darkDecls)) {
  if (modernDecls[k] !== v) {
    fail('modern-dark-mirror', `src/modern.css ${k}: "${modernDecls[k] ?? '(missing)'}" ≠ tokens.css dark "${v}"`)
  }
}
for (const k of Object.keys(modernDecls)) {
  if ((k.startsWith('--color-') || k.startsWith('--kei-') || k.startsWith('--logo-')) && !(k in darkDecls)) {
    fail('modern-dark-mirror', `src/modern.css re-declares ${k}, which the tokens.css dark block does not define`)
  }
}

// 9. The hand-authored Modern section is appended to SPEC.md by `npm run spec`
//    from spec/modern-section.md — same staleness contract as check 6.
try {
  const modernSection = read('spec/modern-section.md')
  if (!read('spec/SPEC.md').includes(modernSection.trim())) {
    fail('spec-md', 'spec/SPEC.md is missing the Modern layer section. Run: npm run spec')
  }
} catch {
  fail('spec-md', 'spec/modern-section.md is missing')
}

if (failures.length) {
  console.error(`\n✗ ${failures.length} drift failure(s):\n`)
  for (const { rule, detail } of failures) console.error(`  [${rule}] ${detail}`)
  console.error('')
  process.exit(1)
}

console.log(`✓ no drift — ${tokenHexes.length} token colors + ${modernHexes.length} modern-layer colors checked against spec ${stamped}`)
