// Build the flattened stylesheet for Claude Design.
//
// Rendered designs receive only styles.css and its transitive @import closure —
// no Tailwind, no bare-specifier resolution. So the uploaded stylesheet must be
// self-contained plain CSS: @apply expanded, @theme unwrapped into :root, and no
// @import of anything the design runtime cannot resolve.
//
// Get this wrong and designs render completely unstyled, which looks like Claude
// Design is broken rather than like a CSS packaging bug.

import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const read = (p) => readFileSync(join(root, p), 'utf8')

const tokens = read('src/tokens.css')
// The Modern layer (§10) is already plain CSS — no @apply — so it ships
// verbatim; only the hand-expanded component block above needs real work.
const modern = read('src/modern.css')

// Pull the two token blocks out verbatim — these are already plain CSS.
const themeBody = tokens.match(/@theme\s*{([\s\S]*?)\n}/)[1]
const darkBody = tokens.match(/\[data-theme="dark"\]\s*{([\s\S]*?)\n}/)[1]

// The component classes, with every Tailwind utility resolved by hand. Kept in
// spec order so a reader can diff this against src/components.css.
const components = `
/* ---- Layout ------------------------------------------------------------- */

.page-width {
  margin-inline: auto;
  width: 100%;
  max-width: 80rem;        /* §04: container 1280px */
  padding-inline: 1.25rem; /* §04: gutters 20px mobile */
}
@media (min-width: 640px) {
  .page-width { padding-inline: 2rem; } /* §04: gutters 32px desktop */
}

/* ---- Typography (§03) --------------------------------------------------- */

/* Eyebrows are JetBrains Mono 500 at +0.18em. A bold sans equivalent looks
   close and violates §03 — this is the single most-repeated brand bug. */
.eyebrow {
  display: inline-flex;
  align-items: center;
  gap: .5rem;
  font-family: var(--font-mono);
  font-size: .75rem;
  line-height: 1rem;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: .18em;
  color: var(--color-accent-text);
}

.nav-link {
  border: 0;
  background: transparent;
  font-size: .875rem;
  line-height: 1.25rem;
  font-weight: 500;
  transition: color .15s ease, background-color .15s ease;
  color: var(--color-muted);
}
.nav-link:hover { color: var(--color-content); }

/* ---- Buttons (§04: 9999px radius; §07: secondary loses its fill on dark) -- */

.button-primary,
.button-secondary,
.button-dark {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: .5rem;
  border-radius: 9999px;
  font-size: .875rem;
  line-height: 1.25rem;
  font-weight: 600;
  transition: background-color .15s ease, border-color .15s ease, color .15s ease;
}
.button-primary:focus-visible,
.button-secondary:focus-visible,
.button-dark:focus-visible {
  outline: 2px solid var(--color-accent-text);
  outline-offset: 2px;
}

.button-primary {
  padding: .75rem 1.25rem;
  box-shadow: 0 1px 2px rgba(0, 0, 0, .05); /* §04: the one shadow */
  background: var(--color-accent);
  border: 1px solid var(--color-accent);
  color: var(--color-on-accent);
}
.button-primary:hover {
  background: var(--color-accent-hover);
  border-color: var(--color-accent-hover);
}

.button-secondary {
  padding: .75rem 1.25rem;
  border: 1px solid var(--color-line-strong);
  background: var(--color-surface);
  color: var(--color-content);
}
.button-secondary:hover { border-color: var(--color-accent-text); }
/* §07: a white card floating on ink reads as a modal, not a button. */
[data-theme="dark"] .button-secondary {
  background: transparent;
  border-color: #ffffff33;
  color: var(--color-content);
}

.button-dark {
  padding: .625rem 1.25rem;
  background: var(--color-tile);
  color: var(--color-on-tile);
}
.button-dark:hover {
  background: var(--color-accent);
  color: var(--color-on-accent);
}

/* ---- Fields (§04: 12px radius; §07: recessed below the card) ------------- */

.field-label {
  display: grid;
  gap: .5rem;
  font-size: .875rem;
  line-height: 1.25rem;
  font-weight: 600;
  color: var(--color-content);
}

.field {
  width: 100%;
  border-radius: .75rem;
  padding: .75rem 1rem;
  font-weight: 400;
  box-shadow: 0 1px 2px rgba(0, 0, 0, .05);
  transition: border-color .15s ease, box-shadow .15s ease;
  border: 1px solid var(--color-line-strong);
  background: var(--color-field);
  color: var(--color-content);
}
.field::placeholder { color: var(--color-faint); }
.field:focus {
  outline: none;
  border-color: var(--color-accent-text);
  box-shadow: 0 0 0 2px color-mix(in srgb, var(--color-accent-text) 20%, transparent);
}

.answer-card {
  display: flex;
  cursor: pointer;
  align-items: center;
  gap: 1rem;
  border-radius: 1rem;
  padding: 1rem;
  font-size: .875rem;
  line-height: 1.5rem;
  transition: border-color .15s ease, background-color .15s ease;
  border: 1px solid var(--color-line);
  color: var(--color-muted);
}
.answer-card:hover {
  border-color: var(--color-accent-text);
  background: color-mix(in srgb, var(--color-accent-text) 8%, transparent);
}
.answer-card-selected {
  border-color: var(--color-accent-text);
  background: color-mix(in srgb, var(--color-accent-text) 12%, transparent);
  color: var(--color-content);
  box-shadow: inset 0 0 0 1px var(--color-accent-text);
}

/* ---- Surfaces that follow the theme ------------------------------------- */

.surface { background: var(--color-surface); }
.surface-raised { background: var(--color-surface-hover); }
.risk-card { background: var(--color-risk-bg); border-color: var(--color-risk-line); }
.risk-ink { color: var(--color-risk-ink); }
.hairline { border-color: var(--color-line); }
.text-muted { color: var(--color-muted); }
.text-faint { color: var(--color-faint); }

/* ---- Kei access view atoms (HP-C12) ------------------------------------ */
.effect-pill { display: inline-flex; align-items: center; gap: .375rem; border-radius: 9999px; padding: .125rem .625rem; font-size: .75rem; line-height: 1rem; font-weight: 500; border: 1px solid; white-space: nowrap; }
.effect-pill-permit { color: var(--kei-permit-ink); background: var(--kei-permit-bg); border-color: var(--kei-permit-line); }
.effect-pill-deny { color: var(--kei-deny-ink); background: var(--kei-deny-bg); border-color: var(--kei-deny-line); }
.effect-pill-dot { width: 6px; height: 6px; border-radius: 9999px; background: currentColor; }
.status-dot { display: inline-flex; align-items: center; gap: .375rem; color: var(--color-muted); font-size: .75rem; line-height: 1rem; }
.status-dot-mark { width: 7px; height: 7px; border-radius: 9999px; background: var(--color-line-strong); }
.status-dot-enabled .status-dot-mark { background: var(--color-accent-text); }
.status-dot-disabled { opacity: .55; }
.pattern-tag { display: inline-flex; min-width: 0; max-width: 100%; overflow: hidden; font: 500 12.5px/1.5 var(--font-mono); white-space: nowrap; }
.pattern-tag-prefix { color: var(--color-faint); flex: none; }
.pattern-tag-value { color: var(--color-content); overflow: hidden; text-overflow: ellipsis; }
.origin-tag { display: inline-flex; align-items: center; border-radius: 6px; padding: 2px 8px; font: 500 11.5px/1.45 var(--font-mono); white-space: nowrap; }
.origin-tag-direct { color: var(--color-accent-text); border: 1px solid var(--color-accent-text); }
.origin-tag-via { color: var(--color-muted); border: 1px solid var(--color-line-strong); }
.origin-tag-global { color: var(--color-muted); background: var(--color-surface-hover); border: 1px solid var(--color-line); }
.avatar-stack { display: inline-flex; padding-left: 8px; }
.avatar-stack-item { display: grid; place-items: center; position: relative; margin-left: -8px; width: 32px; height: 32px; flex: none; border: 2px solid var(--color-ground); border-radius: 9999px; font-size: 11.5px; font-weight: 600; }
.avatar-stack-item:nth-child(5n+1) { background: #047857; color: #fff; }
.avatar-stack-item:nth-child(5n+2) { background: #07110d; color: #fff; }
.avatar-stack-item:nth-child(5n+3) { background: #d1fae5; color: #065f46; }
.avatar-stack-item:nth-child(5n+4) { background: #475569; color: #fff; }
.avatar-stack-item:nth-child(5n) { background: #065f46; color: #fff; }
.segmented-control { display: inline-flex; align-items: center; gap: .25rem; border: 1px solid var(--color-line-strong); border-radius: 9999px; padding: 3px; background: var(--color-field); }
.segmented-control-option { cursor: pointer; border: 0; border-radius: 9999px; padding: .375rem .75rem; background: transparent; color: var(--color-muted); font-size: .75rem; line-height: 1rem; font-weight: 500; }
.segmented-control-option.is-active { background: var(--color-content); color: var(--color-ground); }
.filter-chip { display: inline-flex; align-items: center; cursor: pointer; border: 1px solid var(--color-line-strong); border-radius: 9999px; padding: 4px 11px; background: transparent; color: var(--color-muted); font-size: .75rem; line-height: 1rem; }
.filter-chip.is-selected { border-color: var(--color-accent-text); color: var(--color-content); background: color-mix(in srgb, var(--color-accent-text) 12%, transparent); }
.segmented-control-option:focus-visible, .filter-chip:focus-visible { outline: 2px solid var(--color-accent-text); outline-offset: 2px; }

@keyframes fade-in { from { opacity: 0; } to { opacity: 1; } }
.animate-fade-in { animation: fade-in .2s ease-out; }
`.trim()

const out = `/* Haikei Labs design system — flattened stylesheet for Claude Design.

   GENERATED by scripts/build-flat-css.mjs. Do not edit: edit src/tokens.css and
   the component block in that script instead.

   Self-contained plain CSS by design — rendered designs receive only this file
   and its @import closure, so there is no Tailwind here to resolve @apply and no
   bare specifier that would fail to load.

   Brand spec v0.2. Source of truth: spec/Haikei Design Spec.dc.html.
   §02 colour · §03 typography · §04 website · §07 dark mode · §10 Modern layer. */

@import url("https://fonts.googleapis.com/css2?family=Inter:ital,wght@0,400;0,500;0,600;1,400;1,500&family=JetBrains+Mono:wght@500&display=swap");

/* Tokens — light. Tailwind's @theme unwrapped to :root so this needs no build. */
:root {${themeBody}
}

/* Tokens — dark (§07). Ink becomes the page ground and emerald 700 stops
   carrying text: mint 300 takes over every text, link, icon and eyebrow role,
   because emerald 700 on near-black measures 3.50:1 and fails WCAG AA. Emerald
   700 keeps only its solid-fill jobs: buttons and the one full-bleed CTA band. */
[data-theme="dark"] {${darkBody}
}

/* Follow the OS when no explicit choice has been stored. */
@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]) {${darkBody}
  }
}

html { scroll-behavior: smooth; }
body {
  margin: 0;
  min-width: 320px;
  background: var(--color-ground);
  color: var(--color-content);
  font-family: var(--font-sans);
  -webkit-font-smoothing: antialiased;
  transition: background-color .2s ease, color .2s ease;
}
button, a, input, select, textarea { outline-color: var(--color-accent-text); }
button:disabled { cursor: not-allowed; opacity: .55; }

${components}

/* ---- Modern layer (§10) --------------------------------------------------
   Opt-in via [data-style="modern"] on a root or wrapper. Shipped verbatim from
   src/modern.css. */

${modern}

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    scroll-behavior: auto !important;
    animation-duration: .01ms !important;
    transition-duration: .01ms !important;
  }
}
`

mkdirSync(join(root, 'dist'), { recursive: true })
writeFileSync(join(root, 'dist/styles.flat.css'), out)

// Guard the failure modes this file exists to prevent. Checked against the CSS
// with comments stripped, since the prose above legitimately names @apply.
const code = out.replace(/\/\*[\s\S]*?\*\//g, '')
const problems = []
if (/@apply/.test(code)) problems.push('@apply survived — designs would render unstyled')
if (/@import\s+["']tailwindcss["']/.test(code)) problems.push('a bare tailwindcss import survived')
if (/@theme/.test(code)) problems.push('@theme survived — it needs Tailwind to mean anything')
if (!/--color-accent:\s*#047857/.test(code)) problems.push('emerald 700 is missing')
if (!/--color-accent-text:\s*#6ee7b7/.test(code)) problems.push('the §07 dark accent-text flip is missing')

if (problems.length) {
  console.error('✗ flattening failed:')
  for (const p of problems) console.error(`  - ${p}`)
  process.exit(1)
}

console.log(`✓ dist/styles.flat.css — ${(out.length / 1024).toFixed(1)} KB, plain CSS, no @apply`)
