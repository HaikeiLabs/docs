// The §04 motion pieces, exercised from the built output (run after `npm run build`).
// There is no jsdom in this repo, so the hero field runs against a minimal DOM stub:
// enough to prove the canvas contract (inserted first, aria-hidden, inert to pointers)
// and that stop() tears everything down.
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import postcss from 'postcss'

const { mountHeroField } = await import('../dist/motion/hero-field.js')
const { KeiFlow } = await import('../dist/motion/kei-flow.js')
const entry = await import('../dist/index.js').catch(() => null) // needs Solid's browser build; covered by check-package

test('motion modules export functions', () => {
  assert.equal(typeof mountHeroField, 'function')
  assert.equal(typeof KeiFlow, 'function')
  if (entry) {
    assert.equal(entry.mountHeroField, mountHeroField)
    assert.equal(entry.KeiFlow, KeiFlow)
  }
})

function stubDom({ reduce }) {
  const observers = []
  const ctx = new Proxy({}, { get: (t, k) => (k in t ? t[k] : () => {}), set: (t, k, v) => ((t[k] = v), true) })
  const canvas = {
    attrs: {}, style: {}, removed: false,
    setAttribute(k, v) { this.attrs[k] = v },
    getContext: () => ctx,
    remove() { this.removed = true; host.children = host.children.filter(c => c !== this) },
  }
  const listeners = new Map()
  const documentListeners = new Map()
  const host = {
    children: [{ tag: 'h1' }],
    prepend(c) { this.children.unshift(c) },
    getBoundingClientRect: () => ({ left: 0, top: 0, width: 800, height: 480 }),
    addEventListener: (t, f) => listeners.set(t, f),
    removeEventListener: (t, f) => { if (listeners.get(t) === f) listeners.delete(t) },
  }
  class Observer { constructor(callback) { this.callback = callback; this.on = false; observers.push(this) } observe() { this.on = true } disconnect() { this.on = false } }
  const frames = new Map()
  let nextFrame = 0
  const timers = new Set()
  Object.assign(globalThis, {
    document: { createElement: () => canvas, hidden: false, addEventListener: (t, f) => documentListeners.set(t, f), removeEventListener: (t, f) => { if (documentListeners.get(t) === f) documentListeners.delete(t) } },
    window: { devicePixelRatio: 2 },
    matchMedia: () => ({ matches: reduce }),
    getComputedStyle: () => ({ getPropertyValue: () => '' }),
    ResizeObserver: Observer, IntersectionObserver: Observer,
    requestAnimationFrame: f => { const id = ++nextFrame; frames.set(id, f); return id }, cancelAnimationFrame: id => frames.delete(id),
  })
  const realSet = globalThis.setTimeout, realClear = globalThis.clearTimeout
  globalThis.setTimeout = (f, ms) => { const id = realSet(f, ms); timers.add(id); return id }
  globalThis.clearTimeout = id => { timers.delete(id); realClear(id) }
  const restore = () => { globalThis.setTimeout = realSet; globalThis.clearTimeout = realClear }
  return { host, canvas, listeners, documentListeners, observers, timers, frames, restore }
}

test('pointer updates share a frame and animation pauses off-screen or in hidden tabs', () => {
  const dom = stubDom({ reduce: false })
  try {
    const stop = mountHeroField(dom.host)
    const move = dom.listeners.get('pointermove')
    move({ clientX: 100, clientY: 100 }); move({ clientX: 120, clientY: 120 })
    assert.equal(dom.frames.size, 1)
    dom.observers[1].callback([{ isIntersecting: false }])
    assert.equal(dom.frames.size, 0)
    move({ clientX: 100, clientY: 100 })
    assert.equal(dom.frames.size, 0)
    dom.observers[1].callback([{ isIntersecting: true }])
    assert.equal(dom.frames.size, 1)
    document.hidden = true
    dom.documentListeners.get('visibilitychange')()
    assert.equal(dom.frames.size, 0)
    document.hidden = false
    dom.documentListeners.get('visibilitychange')()
    assert.equal(dom.frames.size, 1)
    stop()
    assert.equal(dom.frames.size, 0)
  } finally { dom.restore() }
})

for (const reduce of [false, true]) {
  test(`mountHeroField adds an aria-hidden canvas and stop() removes it (reduced motion: ${reduce})`, () => {
    const dom = stubDom({ reduce })
    try {
      const stop = mountHeroField(dom.host)
      assert.equal(dom.host.children[0], dom.canvas, 'canvas is the first child')
      assert.equal(dom.canvas.attrs['aria-hidden'], 'true')
      assert.equal(dom.canvas.style.pointerEvents, 'none')
      assert.equal(dom.canvas.width, 1600, 'backing store follows devicePixelRatio')
      assert.ok(dom.listeners.has('pointerdown'))
      assert.equal(dom.listeners.has('pointermove'), !reduce, 'pointer movement only listens when motion is allowed')
      assert.equal(dom.timers.size, reduce ? 0 : 1, 'one load ripple, none under reduced motion')
      assert.ok(dom.observers.every(o => o.on))

      stop()
      assert.ok(dom.canvas.removed)
      assert.equal(dom.host.children.length, 1)
      assert.equal(dom.listeners.size, 0)
      assert.equal(dom.documentListeners.size, 0)
      assert.equal(dom.timers.size, 0)
      assert.ok(dom.observers.every(o => !o.on))
    } finally {
      dom.restore()
    }
  })
}

test('cursor ring has no fill or halo when enlarged', () => {
  const css = postcss.parse(readFileSync(new URL('../src/modern.css', import.meta.url), 'utf8'))
  css.walkRules('.modern-cursor.is-big', rule => {
    assert.ok(!rule.nodes.some(n => /^(background|background-color|box-shadow|filter)$/.test(n.prop)), 'enlarged ring has no fill or halo')
  })
})

test('button bounce is restricted to fine pointers and motion preference', () => {
  const css = postcss.parse(readFileSync(new URL('../src/components.css', import.meta.url), 'utf8'))
  const found = new Set()
  css.walkRules(rule => {
    if (!rule.nodes.some(n => n.prop === 'transform')) return
    for (const name of ['button-primary', 'button-secondary', 'button-dark', 'modern-button']) {
      if (!rule.selector.includes(`.${name}`)) continue
      found.add(name)
      let p = rule.parent, condition = ''
      while (p) { if (p.type === 'atrule' && p.name === 'media') condition += p.params; p = p.parent }
      assert.match(condition, /pointer:\s*fine/)
      assert.match(condition, /prefers-reduced-motion:\s*no-preference/)
    }
  })
  assert.equal(found.size, 4, 'all button variants have a bounce')
})
