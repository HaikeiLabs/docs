import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
const source = name => readFileSync(new URL(`../src/components/${name}.tsx`, import.meta.url), 'utf8')
const index = readFileSync(new URL('../src/index.ts', import.meta.url), 'utf8')
test('Select links labels and errors and supports controlled selection', () => {
  const s = source('Select')
  for (const pattern of [/createUniqueId/, /for=\{selectId\(\)\}/, /aria-describedby=\{errorId\(\)\}/, /aria-invalid/, /option\.selected/, /selectElement\.value/]) assert.match(s, pattern)
  assert.match(index, /export \{ Select/)
})
test('Toggle exposes switch state and reports changes', () => {
  const s = source('Toggle')
  for (const pattern of [/role="switch"/, /aria-checked=\{props.checked\}/, /disabled=\{props.disabled\}/, /props.onChange\(!props.checked\)/]) assert.match(s, pattern)
  assert.match(index, /export \{ Toggle/)
})
test('Tooltip supports focus, hover, Escape and accessible descriptions', () => {
  const s = source('Tooltip')
  for (const pattern of [/onFocus/, /onMouseEnter/, /Escape/, /aria-describedby/, /role="tooltip"/]) assert.match(s, pattern)
  assert.match(index, /export \{ Tooltip/)
})
test('Modal wires a backdrop click to the overlay dismiss handler', () => {
  const s = source('Modal')
  assert.match(s, /import \{ dismissFromOverlay \} from '\.\/modal-dismiss\.js'/)
  assert.match(s, /<Dialog\.Overlay[^>]*onClick=\{dismissFromOverlay\(props\)\}/s)
  assert.match(index, /export \{ Modal/)
})
// Kobalte arms its outside-pointerdown listener on a setTimeout(0); a click on the
// backdrop before that timer runs must still close the dialog (HAI-1040). Timers
// stay frozen throughout, so only the overlay's own handler can close it.
test('Modal backdrop click closes before any timer runs', async (t) => {
  const { dismissFromOverlay } = await import('../dist/components/modal-dismiss.js')
  t.mock.timers.enable({ apis: ['setTimeout', 'setInterval', 'setImmediate'] })
  const calls = []
  const props = { open: true, onOpenChange: (open) => calls.push(open) }
  const overlay = {}
  const onClick = dismissFromOverlay(props)

  onClick({ target: {}, currentTarget: overlay }) // bubbled from inside: not outside
  assert.deepEqual(calls, [])
  onClick({ target: overlay, currentTarget: overlay })
  assert.deepEqual(calls, [false])

  props.open = false // Kobalte closed it first on pointerdown: no second close
  onClick({ target: overlay, currentTarget: overlay })
  assert.deepEqual(calls, [false])
})
