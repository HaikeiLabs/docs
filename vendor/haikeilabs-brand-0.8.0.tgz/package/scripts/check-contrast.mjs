import { readFileSync } from 'node:fs'

// Contrast assertions — brand spec v0.2 §07.
//
// The dark-mode accent split exists because emerald 700 on ink fails WCAG AA for
// body text. These assert the measured figures the spec's rationale rests on, so
// the reasoning cannot silently rot if a token is edited.

const hex = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16) / 255)
const lin = (c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4)
const lum = (h) => { const [r, g, b] = hex(h).map(lin); return 0.2126 * r + 0.7152 * g + 0.0722 * b }
const ratio = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((m, n) => n - m); return (x + 0.05) / (y + 0.05) }

const INK = '#07110d', EMERALD = '#047857', MINT = '#6ee7b7', CANVAS = '#f6f8f6'

const cases = [
  ['emerald 700 on ink', EMERALD, INK, 3.50, 'fails AA — this is WHY accent text flips to mint (§07)'],
  ['mint 300 on ink',    MINT,    INK, 12.58, 'passes AA — the replacement accent-text on dark'],
  ['ink on canvas',      INK,     CANVAS, null, 'body copy, light theme'],
  ['canvas on ink',      CANVAS,  INK, null, 'body copy, dark theme'],
  ['muted on ink',       '#a3b1aa', INK, null, '§10 ticker items + secondary copy in the Modern layer'],
  ['faint on ink',       '#8b978f', INK, null, '§10 stats/ticker labels — small mono text, needs 4.5:1'],
  ['amber ink on white', '#b45309', '#ffffff', 5.02, 'light risk ink on a white surface — passes AA (HAI-1039)'],
  ['amber ink on risk bg', '#b45309', '#fffdf3', 4.93, 'light risk ink on the risk card (rgba(255,251,235,.6) over white) — passes AA'],
]

let failed = 0

// Measure the actual help trigger color against each theme's page ground.
const css = readFileSync(new URL('../src/components.css', import.meta.url), 'utf8')
const tokens = readFileSync(new URL('../src/tokens.css', import.meta.url), 'utf8')
const help = css.match(/\.kei-tooltip-help\s*\{([^}]*)\}/)?.[1] ?? ''
const color = help.match(/(?:^|;)\s*color\s*:\s*([^;]+)/)?.[1]?.trim()
const dark = tokens.match(/\[data-theme="dark"\]\s*\{([^}]*)\}/)?.[1] ?? ''
for (const [theme, block, background] of [['light', tokens, CANVAS], ['dark', dark, INK]]) {
  const token = color?.match(/^var\((--[\w-]+)\)$/)?.[1]
  const fg = token ? block.match(new RegExp(`${token}:\\s*(#[0-9a-fA-F]{6})\\b`))?.[1] : color
  if (!/^#[0-9a-fA-F]{6}$/.test(fg ?? '')) {
    console.error(`  ✗ tooltip ${theme}: cannot resolve trigger color ${color}`)
    failed++
    continue
  }
  const r = ratio(fg, background)
  if (r < 4.5) {
    console.error(`  ✗ tooltip ${theme}: ${r.toFixed(2)}:1, requires 4.5:1`)
    failed++
  } else console.log(`  tooltip ${theme}: ${r.toFixed(2)}:1  AA ✓`)
}
if (!/border\s*:\s*[^;]*\bcurrentColor\b/i.test(help)) {
  console.error('  ✗ tooltip border must follow trigger color')
  failed++
}
for (const [label, fg, bg, expected, note] of cases) {
  const r = ratio(fg, bg)
  const shown = r.toFixed(2)
  if (expected !== null && Math.abs(r - expected) > 0.02) {
    console.error(`  ✗ ${label}: ${shown}:1, spec documents ${expected}:1`)
    failed++
  } else {
    const aa = r >= 4.5 ? 'AA ✓' : 'AA ✗'
    console.log(`  ${label.padEnd(22)} ${shown.padStart(6)}:1  ${aa}  — ${note}`)
  }
}

// The load-bearing invariant: mint must beat emerald on ink, or §07's whole
// rationale for the accent split is wrong.
if (ratio(MINT, INK) <= ratio(EMERALD, INK)) {
  console.error('  ✗ mint does not out-contrast emerald on ink — §07 accent split is unjustified')
  failed++
}

process.exit(failed ? 1 : 0)
