import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'

const component = readFileSync(new URL('../src/components/CredentialStoreSettings.tsx', import.meta.url), 'utf8')
const index = readFileSync(new URL('../src/index.ts', import.meta.url), 'utf8')

test('CredentialStoreSettings is exported as a presentational controlled component', () => {
  assert.match(index, /CredentialStoreSettings/)
  assert.match(component, /onScopeChange/)
  assert.match(component, /onBackendChange/)
  assert.match(component, /onEnabledChange/)
  assert.match(component, /onRemoveOverride/)
  assert.doesNotMatch(component, /createResource|fetch\(|axios/)
})

test('CredentialStoreSettings exposes organization and workspace scope choices', () => {
  assert.match(component, /organization/)
  assert.match(component, /workspace/)
  assert.match(component, /onWorkspaceChange/)
})

test('CredentialStoreSettings offers the supported secret backends', () => {
  assert.match(component, /aws-secrets-manager/)
  assert.match(component, /azure-key-vault/)
  assert.match(component, /gcp-secret-manager/)
  assert.doesNotMatch(component, /prod|sandbox/i)
})

// Render the actual Solid component so these checks cover its public markup.
import { createServer } from 'vite'
import solid from 'vite-plugin-solid'
import { renderToString } from 'solid-js/web'

async function renderSettings(overrides = {}, count = 1) {
  const server = await createServer({ configFile: false, plugins: [solid({ ssr: true })], server: { middlewareMode: true, ws: false }, appType: 'custom' })
  try {
    const { CredentialStoreSettings } = await server.ssrLoadModule('/src/components/CredentialStoreSettings.tsx')
    return renderToString(() => Array.from({ length: count }, () => CredentialStoreSettings({ scope: 'organization', backend: 'aws-secrets-manager', onBackendChange() {}, secretNamePrefix: '', onSecretNamePrefixChange() {}, enabled: true, onEnabledChange() {}, ...overrides })))
  } finally { await server.close() }
}

test('fixed scope renders text while an editable scope offers a selector', async () => {
  const fixed = await renderSettings()
  assert.doesNotMatch(fixed, /<select[^>]*aria-label="Scope"/)
  assert.match(fixed, /Organization default/)
  const workspace = await renderSettings({ scope: 'workspace' })
  assert.doesNotMatch(workspace, /<select[^>]*aria-label="Scope"/)
  assert.match(workspace, /Workspace override/)
  const editable = await renderSettings({ onScopeChange() {} })
  assert.match(editable, /<select[^>]*aria-label="Scope"/)
})

test('prefix and active backend inputs are required', async () => {
  for (const [backend, fields] of [
    ['aws-secrets-manager', ['Secret name prefix', 'AWS account ID', 'AWS region']],
    ['azure-key-vault', ['Secret name prefix', 'Key Vault URI']],
    ['gcp-secret-manager', ['Secret name prefix', 'Project ID']],
  ]) {
    const html = await renderSettings({ backend })
    for (const field of fields) assert.match(html, new RegExp(`<input[^>]*aria-label="${field}"[^>]*required`), field)
  }
})

test('prefix input points to its accessible description with unique IDs', async () => {
  const html = await renderSettings({}, 2)
  const ids = [...html.matchAll(/aria-label="Secret name prefix"[^>]*aria-describedby="([^"]+)"/g)].map(match => match[1])
  assert.equal(new Set(ids).size, 2)
  for (const id of ids) assert.match(html, new RegExp(`id="${id}"[^>]*>[^<]+`))
})
