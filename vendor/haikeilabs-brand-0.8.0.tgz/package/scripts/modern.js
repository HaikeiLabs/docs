/* Modern layer behaviors — the circle cursor and the copyable command.
   Optional and progressive: include on pages that opt into the Modern layer,

     <script src=".../@haikeilabs/brand/modern.js" defer></script>

   and everything degrades gracefully without it — the native cursor stays and
   the command stays selectable text. The layer's CSS lives in modern.css; this
   file adds no styles of its own beyond toggling classes that modern.css
   defines.

   Note for consumers: the circle cursor appends its ring inside the hovered
   [data-style="modern"] root so the layer's tokens resolve. The root must not
   carry a CSS transform or filter, or the fixed-position ring would position
   relative to it instead of the viewport. */

(function () {
  'use strict'

  /* Copyable command: [data-modern-copy] copies its own value, or the text of
     the <code> beside it when the attribute is empty, and flashes the label.
     Delegated at the document level, so it works for markup added later. */
  function flash(btn, txt) {
    var original = btn.textContent
    btn.textContent = txt
    btn.disabled = true
    setTimeout(function () {
      btn.textContent = original
      btn.disabled = false
    }, 1400)
  }
  document.addEventListener('click', function (e) {
    var btn = e.target.closest ? e.target.closest('[data-modern-copy]') : null
    if (!btn) return
    var cmd = btn.closest('[data-modern-cmd], .cmd')
    var code = cmd ? cmd.querySelector('code') : null
    var text = btn.getAttribute('data-modern-copy') || (code ? code.textContent : '')
    if (!text) return
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(
        function () { flash(btn, 'Copied') },
        function () { fallbackCopy(code, btn) }
      )
    } else {
      fallbackCopy(code, btn)
    }
  })
  /* Clipboard API unavailable (http origins, denied permission) — select the
     text so the usual ⌘C/Ctrl+C works, and say so on the button. */
  function fallbackCopy(code, btn) {
    if (!code) return
    var range = document.createRange()
    range.selectNodeContents(code)
    var sel = window.getSelection()
    sel.removeAllRanges()
    sel.addRange(range)
    flash(btn, 'Selected — press ⌘C')
  }

  /* Circle cursor. Fine pointers only, and off entirely under
     prefers-reduced-motion: reduce. */
  var fine = window.matchMedia('(pointer: fine)')
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)')
  if (!fine.matches || reduce.matches) return

  var ring = document.createElement('div')
  ring.className = 'modern-cursor'
  ring.hidden = true

  var root = null
  var shown = false
  var x = 0
  var y = 0
  var tx = 0
  var ty = 0

  function leave() {
    shown = false
    ring.hidden = true
  }
  function detach() {
    leave()
    if (root) {
      root.classList.remove('has-modern-cursor')
      root = null
    }
  }

  document.addEventListener('pointermove', function (e) {
    if (e.pointerType !== 'mouse') { detach(); return }
    var next = e.target.closest ? e.target.closest('[data-style="modern"]') : null
    if (!next) { detach(); return }
    if (next !== root) {
      detach()
      root = next
      root.appendChild(ring)
      root.classList.add('has-modern-cursor')
      shown = true
      ring.hidden = false
      x = tx = e.clientX
      y = ty = e.clientY
    }
    tx = e.clientX
    ty = e.clientY
    ring.classList.toggle(
      'is-big',
      !!(e.target.closest && e.target.closest('a, button, summary, [role="button"]'))
    )
  })
  document.addEventListener('pointerout', function (e) {
    if (!e.relatedTarget) leave() // left the window
  })
  document.addEventListener('blur', leave)

  /* The trailing ring is eased; the grow/shrink is handled by the CSS
     transition in modern.css. */
  ;(function loop() {
    if (shown) {
      x += (tx - x) * 0.28
      y += (ty - y) * 0.28
      ring.style.transform = 'translate(' + x + 'px,' + y + 'px)'
    }
    requestAnimationFrame(loop)
  })()

  /* If the user raises their reduced-motion preference mid-session, stand
     down completely. */
  var onChange = function (e) { if (e.matches) detach() }
  if (reduce.addEventListener) reduce.addEventListener('change', onChange)
  else if (reduce.addListener) reduce.addListener(onChange)
})()
