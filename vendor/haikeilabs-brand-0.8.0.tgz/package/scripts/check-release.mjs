import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'

const { name, version } = JSON.parse(readFileSync('package.json', 'utf8'))
assert.equal(name, '@haikeilabs/brand')
assert.match(version, /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/, 'Only stable semver releases publish to latest')
assert.equal(process.env.TAG_NAME, `v${version}`, 'Tag must exactly match package version')
for (const key of ['AWS_REGION', 'CODEARTIFACT_DOMAIN', 'CODEARTIFACT_OWNER', 'CODEARTIFACT_REPOSITORY', 'AWS_CODEARTIFACT_PUBLISH_ROLE_ARN']) {
  assert.ok(process.env[key]?.trim(), `Missing publication configuration: ${key}`)
}
assert.match(process.env.CODEARTIFACT_OWNER, /^\d{12}$/, 'Domain owner must be a 12-digit AWS account ID')
console.log(`Release configuration valid for ${name}@${version}`)
