#!/usr/bin/env node
import { execFileSync } from 'node:child_process'
import { mkdtemp, mkdir, readFile, writeFile, readdir, copyFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const args = process.argv.slice(2)
if (!(args.length === 1 || (args.length === 3 && args[1] === '--ref' && args[2]))) {
  console.error('Usage: node scripts/vendor-into.mjs <consumer-repo-dir> [--ref <git-ref>]')
  process.exit(1)
}
const consumer = resolve(args[0])
const run = (command, args, cwd) => execFileSync(command, args, { cwd, stdio: 'inherit' })
const temp = await mkdtemp(join(tmpdir(), 'brand-vendor-'))
try {
  const manifestPath = join(consumer, 'package.json')
  const manifest = JSON.parse(await readFile(manifestPath, 'utf8'))
  let source = root
  if (args[1]) {
    source = join(temp, 'source')
    const commit = execFileSync('git', ['rev-parse', '--verify', `${args[2]}^{commit}`], { cwd: root, encoding: 'utf8' }).trim()
    run('git', ['clone', '--no-checkout', '--local', root, source], root)
    run('git', ['checkout', '--detach', commit], source)
    run('npm', ['ci'], source)
  }
  run('npm', ['run', 'build'], source)
  const version = JSON.parse(await readFile(join(source, 'package.json'), 'utf8')).version
  const filename = `haikeilabs-brand-${version}.tgz`
  run('npm', ['pack', '--pack-destination', temp], source)
  const vendor = join(consumer, 'vendor')
  await mkdir(vendor, { recursive: true })
  await copyFile(join(temp, filename), join(vendor, filename))
  for (const name of await readdir(vendor)) {
    if (/^haikeilabs-brand-.*\.tgz$/.test(name) && name !== filename) await rm(join(vendor, name))
  }
  manifest.dependencies ??= {}
  manifest.dependencies['@haikeilabs/brand'] = `file:vendor/${filename}`
  await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`)
  console.log(`Vendored ${filename}. Next: cd ${JSON.stringify(consumer)} && npm install`)
} finally { await rm(temp, { recursive: true, force: true }) }
