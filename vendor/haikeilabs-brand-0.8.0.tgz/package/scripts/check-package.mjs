// Exercise the tarball consumers receive, not a workspace/source alias.
import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync, rmSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { build } from 'vite'
import solid from 'vite-plugin-solid'
import tailwind from '@tailwindcss/postcss'

const root = resolve('.')
const temp = mkdtempSync(join(root, '.package-test-'))
try {
  const [pack] = JSON.parse(execFileSync('npm', ['pack', '--json', '--ignore-scripts', '--pack-destination', temp], { encoding: 'utf8' }))
  assert.equal(pack.name, '@haikeilabs/brand')
  const lock = JSON.parse(readFileSync('package-lock.json'))
  assert.equal(lock.version, pack.version)
  assert.equal(lock.packages[''].version, pack.version)
  const pkgDir = join(temp, 'node_modules/@haikeilabs/brand')
  mkdirSync(pkgDir, { recursive: true })
  execFileSync('tar', ['-xzf', join(temp, pack.filename), '--strip-components=1', '-C', pkgDir])
  const pkg = JSON.parse(readFileSync(join(pkgDir, 'package.json')))
  const files = new Set(pack.files.map(file => file.path))
  function checkTarget(target) {
    if (typeof target === 'object') return Object.values(target).forEach(checkTarget)
    if (target.includes('*')) {
      assert.ok([...files].some(file => file.startsWith(target.slice(2).split('*')[0])), `Empty wildcard export: ${target}`)
    } else assert.ok(files.has(target.slice(2)), `Missing export: ${target}`)
  }
  Object.values(pkg.exports).forEach(checkTarget)
  assert.ok(files.has('dist/styles.flat.css'))
  // Partner badges ship unmodified with their usage rules (HAI-1032).
  for (const file of [
    'nvidia-inception-program-badge-rgb-for-screen.svg',
    'nvidia-inception-program-badge-rgb-for-screen.png',
    'nvidia-inception-program-badge-rgb-1c-blk-for-screen.svg',
    'nvidia-inception-program-badge-rgb-1c-blk-for-screen.png',
    'ATTRIBUTION.md',
  ]) {
    const path = `assets/partners/${file}`
    assert.ok(files.has(path), `Missing partner asset: ${path}`)
    assert.ok(readFileSync(join(pkgDir, path)).equals(readFileSync(path)), `Packed partner asset differs from source: ${path}`)
  }
  assert.ok(![...files].some(file => /(^|\/)\.npmrc$|\.tgz$|^spec\//.test(file)))
  // Node's browser condition exercises the compiled default entry without a bundler.
  const probe = join(temp, 'probe.mjs')
  writeFileSync(probe, `import * as brand from '@haikeilabs/brand';
    for (const name of ['Button','Card','GithubIcon','Input','Logo','Modal','Table','Pagination','ThemeToggle']) {
      if (typeof brand[name] !== 'function') throw new Error('Missing component: ' + name)
    }
    // The motion modules are framework-free: importable without Solid's browser build.
    const { mountHeroField } = await import('@haikeilabs/brand/hero-field.js')
    const { KeiFlow } = await import('@haikeilabs/brand/kei-flow.js')
    if (typeof mountHeroField !== 'function' || brand.mountHeroField !== mountHeroField) throw new Error('Missing export: mountHeroField')
    if (typeof KeiFlow !== 'function' || brand.KeiFlow !== KeiFlow) throw new Error('Missing export: KeiFlow')`)
  execFileSync(process.execPath, ['--conditions=browser', probe], { stdio: 'inherit' })
  writeFileSync(join(temp, 'package.json'), '{"type":"module"}')
  writeFileSync(join(temp, 'index.html'), '<div id="root"></div><script type="module" src="/main.tsx"></script>')
  writeFileSync(join(temp, 'main.tsx'), `import { render } from 'solid-js/web';
    import * as brand from '@haikeilabs/brand';
    import tokens from '@haikeilabs/brand/tokens.json';
    import theme from '@haikeilabs/brand/theme-init.js?raw';
    import logo from '@haikeilabs/brand/assets/logo/haikei-lockup-on-light.svg';
    import nvidiaBadge from '@haikeilabs/brand/assets/partners/nvidia-inception-program-badge-rgb-for-screen.svg';
    import './style.css';
    console.log(brand, tokens, theme, logo, nvidiaBadge);
    render(() => <brand.Button>Consumer smoke test</brand.Button>, document.getElementById('root')!);`)
  writeFileSync(join(temp, 'style.css'), '@import "tailwindcss";\n@import "@haikeilabs/brand/index.css";\n@import "@haikeilabs/brand/fonts.css";')
  await build({ root: temp, configFile: false, plugins: [solid()], css: { postcss: { plugins: [tailwind()] } }, build: { outDir: join(temp, 'output'), minify: false } })
  console.log('Packed exports, default runtime, and Solid/Vite/Tailwind consumer build passed')
} finally {
  rmSync(temp, { recursive: true, force: true })
}
