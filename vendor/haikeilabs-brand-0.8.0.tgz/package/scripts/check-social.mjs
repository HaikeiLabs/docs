// Verify the committed C5 outputs are PNGs with the dimensions consumers expect.
import { readFileSync } from 'node:fs'
import assert from 'node:assert/strict'

const repos = ['agentware', 'skills', 'docs', 'kei-cli', 'kei-agents', 'kei-connector-contracts', 'github-workflows']
const cards = [['share-card-dark-1200x627.png', 1200, 627], ...repos.map(repo => [`repo-${repo}-1280x640.png`, 1280, 640])]
for (const [name, width, height] of cards) {
  const bytes = readFileSync(new URL(`../assets/social/${name}`, import.meta.url))
  assert.deepEqual(bytes.subarray(0, 8), Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), `${name} must be a PNG`)
  assert.equal(bytes.toString('ascii', 12, 16), 'IHDR', `${name} must have an IHDR`)
  assert.equal(bytes.readUInt32BE(16), width, `${name} width`)
  assert.equal(bytes.readUInt32BE(20), height, `${name} height`)
  console.log(`  ${name}: ${width}×${height}`)
}
