// Preview-card check.
//
// Cards are hand-authored (the /design-sync converter does not apply here), so nothing
// else guarantees they stay consistent with the stylesheet they render against. A card
// referencing a class or token that styles.css does not define renders unstyled, and
// the failure is invisible until someone opens the project.

import { readFileSync, readdirSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const read = (p) => readFileSync(join(root, p), 'utf8')

const css = read('dist/styles.flat.css').replace(/\/\*[\s\S]*?\*\//g, '')
const defined = new Set([...css.matchAll(/\.([a-zA-Z][\w-]*)/g)].map((m) => m[1]))
const tokens = new Set([...css.matchAll(/(--[\w-]+)\s*:/g)].map((m) => m[1]))

const failures = []
const cardsDir = join(root, 'design-cards')

for (const name of readdirSync(cardsDir, { withFileTypes: true }).filter((d) => d.isDirectory())) {
  const file = `design-cards/${name.name}/${name.name}.html`
  let html
  try {
    html = read(file)
  } catch {
    failures.push(`${name.name}: no ${name.name}.html`)
    continue
  }

  if (!html.startsWith('<!-- @dsCard group=')) {
    failures.push(`${file}: first line must be the @dsCard marker or the card never registers`)
  }

  // Classes defined in the card's own <style> block are legitimate.
  const style = html.match(/<style>([\s\S]*?)<\/style>/)?.[1] ?? ''
  const local = new Set([...style.matchAll(/\.([a-zA-Z][\w-]*)\s*[,{:]/g)].map((m) => m[1]))

  const used = new Set(
    [...html.matchAll(/class="([^"]+)"/g)].flatMap((m) => m[1].split(/\s+/)).filter(Boolean),
  )
  for (const c of used) {
    if (!defined.has(c) && !local.has(c)) failures.push(`${file}: class .${c} is not defined anywhere`)
  }

  for (const [, t] of html.matchAll(/var\((--[\w-]+)/g)) {
    if (!tokens.has(t)) failures.push(`${file}: token ${t} is not defined in styles.css`)
  }

  if (!html.includes('styles.css')) {
    failures.push(`${file}: does not link styles.css, so it renders unstyled`)
  }
}

if (failures.length) {
  console.error(`\n✗ ${failures.length} card problem(s):\n`)
  for (const f of failures) console.error(`  ${f}`)
  console.error('')
  process.exit(1)
}

const n = readdirSync(cardsDir, { withFileTypes: true }).filter((d) => d.isDirectory()).length
console.log(`✓ ${n} preview cards — every class and token resolves`)
