import { test } from 'node:test'
import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { readFileSync } from 'node:fs'
const { version } = JSON.parse(readFileSync('package.json'))
const env = { ...process.env, TAG_NAME: `v${version}`, AWS_REGION: 'us-east-1', CODEARTIFACT_DOMAIN: 'example', CODEARTIFACT_OWNER: '123456789012', CODEARTIFACT_REPOSITORY: 'brand', AWS_CODEARTIFACT_PUBLISH_ROLE_ARN: 'arn:aws:iam::123456789012:role/publish' }
const run = overrides => spawnSync(process.execPath, ['scripts/check-release.mjs'], { env: { ...env, ...overrides } }).status
test('valid release configuration', () => assert.equal(run({}), 0))
test('reject mismatched and prerelease tags', () => {
   for (const TAG_NAME of ['v9.9.9', `v${version}-rc.1`, version]) assert.notEqual(run({ TAG_NAME }), 0)
 })
test('reject missing infrastructure configuration', () => {
   for (const key of ['AWS_REGION', 'CODEARTIFACT_DOMAIN', 'CODEARTIFACT_OWNER', 'CODEARTIFACT_REPOSITORY', 'AWS_CODEARTIFACT_PUBLISH_ROLE_ARN']) assert.notEqual(run({ [key]: '' }), 0)
   assert.notEqual(run({ CODEARTIFACT_OWNER: 'not-an-account' }), 0)
 })
