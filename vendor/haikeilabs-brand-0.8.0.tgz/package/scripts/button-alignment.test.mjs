import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import postcss from 'postcss'
import tailwindcss from '@tailwindcss/postcss'

const components = readFileSync(new URL('../src/components.css', import.meta.url), 'utf8')
const button = readFileSync(new URL('../src/components/Button.tsx', import.meta.url), 'utf8')
const flatBuilder = readFileSync(new URL('./build-flat-css.mjs', import.meta.url), 'utf8')
const css = postcss([tailwindcss()]).process(
  `@import "tailwindcss";\n@source inline("w-full justify-between");\n${components}`,
  { from: 'button-alignment-test.css' },
)

function rule(root, selector) {
  let found
  root.walkRules(selector, node => { if (node.selector === selector) found = node })
  assert.ok(found, `missing ${selector}`)
  return found
}
function declaration(node, property) {
  let value
  node.walkDecls(property, decl => { value = decl.value })
  return value
}

for (const variant of ['primary', 'secondary', 'dark']) {
  test(`button-${variant} centres content in both stylesheets`, async () => {
    const root = (await css).root
    assert.equal(declaration(rule(root, `.button-${variant}`), 'justify-content'), 'center')
    const flat = flatBuilder.match(/\.button-primary,\s*\.button-secondary,\s*\.button-dark\s*\{([^}]+)\}/)?.[1]
    assert.match(flat ?? '', /justify-content:\s*center\s*;/)
  })
}

test('full-width Button centres its label and caller utilities can override alignment', async () => {
  const root = (await css).root
  assert.match(button, /primary:\s*'button-primary'/)
  assert.match(button, /\$\{local\.class \?\? ''\}/)
  assert.match(button, /\{local\.children\}/)
  assert.equal(declaration(rule(root, '.w-full'), 'width'), '100%')
  const base = rule(root, '.button-primary')
  const override = rule(root, '.justify-between')
  assert.equal(declaration(base, 'justify-content'), 'center')
  assert.equal(declaration(override, 'justify-content'), 'space-between')
  assert.equal(base.parent.params, 'components')
  assert.equal(override.parent.params, 'utilities')
  assert.match((await css).css, /@layer theme, base, components, utilities/)
  const sizes = button.match(/const sizes:[\s\S]*?\n}/)?.[0] ?? ''
  assert.doesNotMatch(sizes, /justify-|justify-content/)
})
