import { readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const dist = new URL('../dist/', import.meta.url)

function rewrite(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name)
    if (entry.isDirectory()) {
      rewrite(path)
      continue
    }
    if (!entry.name.endsWith('.js')) continue
    const source = readFileSync(path, 'utf8')
    writeFileSync(path, source.replaceAll('solid-js/jsx-runtime', 'solid-js/h/jsx-runtime'))
  }
}

rewrite(dist.pathname)
