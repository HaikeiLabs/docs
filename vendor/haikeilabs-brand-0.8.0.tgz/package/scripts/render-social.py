#!/usr/bin/env python3
"""Render the social-card SVG template with Pillow (python3 -m pip install Pillow).

The deliberately small SVG subset keeps the template portable and the output
repeatable. The checked-in Inter fonts are licensed under scripts/social-fonts.
"""
from pathlib import Path
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
TEMPLATE = (ROOT / 'assets/social/card-template.svg').read_text()
OUT = ROOT / 'assets/social'
SCALE = 3
CARDS = [
    ('share-card-dark-1200x627', 1200, 627, 'Think creatively. Act deterministically.', 'Context and guardrails for the systems you run and the agents you build.', 58, 29),
    ('repo-agentware-1280x640', 1280, 640, 'agentware', 'The open-source SDK we build our own agents with.', 78, 32),
    ('repo-skills-1280x640', 1280, 640, 'skills', 'Haikei Skills for the coding assistant you use.', 78, 32),
    ('repo-docs-1280x640', 1280, 640, 'docs', 'Build agents and add guardrails with Haikei.', 78, 32),
    ('repo-kei-cli-1280x640', 1280, 640, 'kei-cli', 'Set up a Kei runtime and manage policies from the command line.', 78, 30),
    ('repo-kei-agents-1280x640', 1280, 640, 'kei-agents', 'Agent identity and permission metadata for the Kei platform.', 78, 32),
    ('repo-kei-connector-contracts-1280x640', 1280, 640, 'kei-connector-contracts', 'Shared contracts for Kei connectors and tool calls.', 70, 32),
    ('repo-github-workflows-1280x640', 1280, 640, 'github-workflows', 'Reusable GitHub Actions workflows for Haikei Labs repositories.', 78, 30),
]

def render(card):
    name, width, height, title, subtitle, title_size, subtitle_size = card
    values = dict(width=width, height=height, title=escape(title), subtitle=escape(subtitle),
                  title_y=330, subtitle_y=410, accent_y=height-79,
                  title_size=title_size, subtitle_size=subtitle_size)
    svg = TEMPLATE
    for key, value in values.items():
        svg = svg.replace('{{' + key + '}}', str(value))
    root = ET.fromstring(svg)
    image = Image.new('RGB', (width*SCALE, height*SCALE))
    draw = ImageDraw.Draw(image)
    def n(element, key, default=0): return float(element.get(key, default)) * SCALE
    for el in root:
        kind = el.tag.split('}')[-1]
        fill = el.get('fill', '#000000')
        fill = None if fill == 'none' else fill
        if kind == 'rect':
            x, y, w, h = (n(el, a) for a in ('x', 'y', 'width', 'height'))
            stroke = el.get('stroke')
            sw = round(n(el, 'stroke-width'))
            # SVG strokes are centered on the shape boundary.
            box = (x-sw/2, y-sw/2, x+w+sw/2, y+h+sw/2) if stroke else (x, y, x+w, y+h)
            draw.rounded_rectangle(box, radius=n(el, 'rx')+sw/2, fill=fill, outline=stroke, width=sw or 1)
        elif kind == 'circle':
            x, y, radius = (n(el, a) for a in ('cx', 'cy', 'r'))
            draw.ellipse((x-radius, y-radius, x+radius, y+radius), fill=fill)
        elif kind == 'text':
            weight = el.get('font-weight')
            font = ImageFont.truetype(str(ROOT / f'scripts/social-fonts/inter-latin-{weight}-normal.woff2'), round(n(el, 'font-size')))
            xy = (n(el, 'x'), n(el, 'y'))
            box = draw.textbbox(xy, el.text, font=font, anchor='ls')
            if box[0] < 40*SCALE or box[1] < 40*SCALE or box[2] > (width-40)*SCALE or box[3] > (height-40)*SCALE:
                raise ValueError(f'{name}: text outside 40px safe area: {el.text}')
            draw.text(xy, el.text, font=font, fill=fill, anchor='ls')
        else:
            raise ValueError(f'Unsupported SVG element: {kind}')
    image.resize((width, height), Image.Resampling.LANCZOS).save(OUT / f'{name}.png', optimize=True)

for card in CARDS:
    render(card)
